// Copyright 2010-2021, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "converter/converter.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "absl/container/flat_hash_set.h"
#include "absl/log/check.h"
#include "absl/log/log.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/string_view.h"
#include "absl/types/span.h"
#include "base/container/tuple.h"
#include "base/util.h"
#include "composer/composer.h"
#include "composer/table.h"
#include "config/config_handler.h"
#include "converter/attribute.h"
#include "converter/candidate.h"
#include "converter/converter_interface.h"
#include "converter/converter_util.h"
#include "converter/immutable_converter.h"
#include "converter/immutable_converter_interface.h"
#include "converter/inner_segment.h"
#include "converter/segments.h"
#include "converter/segments_matchers.h"
#include "data_manager/data_manager.h"
#include "data_manager/testing/mock_data_manager.h"
#include "dictionary/dictionary_interface.h"
#include "dictionary/dictionary_mock.h"
#include "dictionary/dictionary_token.h"
#include "dictionary/pos_matcher.h"
#include "dictionary/user_dictionary.h"
#include "dictionary/user_pos.h"
#include "engine/engine.h"
#include "engine/mock_data_engine_factory.h"
#include "engine/modules.h"
#include "engine/supplemental_model_mock.h"
#include "prediction/predictor.h"
#include "prediction/predictor_interface.h"
#include "prediction/result.h"
#include "protocol/commands.pb.h"
#include "protocol/config.pb.h"
#include "protocol/user_dictionary_storage.pb.h"
#include "request/conversion_request.h"
#include "request/request_test_util.h"
#include "rewriter/date_rewriter.h"
#include "rewriter/rewriter.h"
#include "rewriter/rewriter_interface.h"
#include "testing/gmock.h"
#include "testing/gunit.h"
#include "testing/mozctest.h"
#include "testing/test_peer.h"
#include "transliteration/transliteration.h"

namespace mozc {
namespace converter {

class ConverterTestPeer : public testing::TestPeer<Converter> {
 public:
  explicit ConverterTestPeer(Converter& converter)
      : testing::TestPeer<Converter>(converter) {}

  PEER_METHOD(CompletePosIds);
  PEER_METHOD(PopulatePredictionResultsToSegments);
  PEER_STATIC_METHOD(MaybeSetConsumedKeySizeToSegment);
};

namespace {

using ::mozc::dictionary::DictionaryInterface;
using ::mozc::dictionary::MockDictionary;
using ::mozc::dictionary::MockUserDictionary;
using ::mozc::dictionary::PosMatcher;
using ::mozc::dictionary::Token;
using ::mozc::dictionary::UserDictionary;
using ::mozc::prediction::Predictor;
using ::mozc::prediction::PredictorInterface;
using ::mozc::prediction::Result;
using ::testing::_;
using ::testing::AnyNumber;
using ::testing::Return;
using ::testing::StrEq;

using UserEntry = user_dictionary::UserDictionary::Entry;

Segment& AddSegment(absl::string_view key, Segment::SegmentType type,
                    Segments& segments) {
  Segment* segment = segments.add_segment();
  segment->set_key(key);
  segment->set_segment_type(type);
  return *segment;
}

void PushBackCandidate(absl::string_view text, Segment& segment) {
  Candidate* cand = segment.push_back_candidate();
  cand->key = std::string(text);
  cand->content_key = cand->key;
  cand->value = cand->key;
  cand->content_value = cand->key;
}

class StubPredictor : public PredictorInterface {
 public:
  StubPredictor() : predictor_name_("StubPredictor") {}

  std::vector<Result> Predict(const ConversionRequest& request) const override {
    absl::string_view key = request.key();
    if (key.empty()) {
      return {};
    }
    Result result;
    result.key = key;
    result.value = key;
    return {result};
  }

  absl::string_view GetPredictorName() const override {
    return predictor_name_;
  }

 private:
  const std::string predictor_name_;
};

class StubRewriter : public RewriterInterface {
  bool Rewrite(const ConversionRequest& request,
               Segments* segments) const override {
    return true;
  }
};

class InsertPlaceholderWordsRewriter : public RewriterInterface {
  bool Rewrite(const ConversionRequest&, Segments* segments) const override {
    for (Segment& segment : segments->conversion_segments()) {
      {
        Candidate* cand = segment.add_candidate();
        cand->key = "tobefiltered";
        cand->value = "ToBeFiltered";
      }
      {
        Candidate* cand = segment.add_candidate();
        cand->key = "nottobefiltered";
        cand->value = "NotToBeFiltered";
      }
    }
    return true;
  }
};

class ResizeSegmentsRewriter : public RewriterInterface {
 public:
  ResizeSegmentsRewriter(size_t segment_index,
                         std::array<uint8_t, 8> segment_sizes)
      : segment_index_(segment_index), segment_sizes_(segment_sizes) {}

  bool Rewrite(const ConversionRequest& request,
               Segments* segments) const override {
    return true;
  }

  std::optional<RewriterInterface::ResizeSegmentsRequest>
  CheckResizeSegmentsRequest(const ConversionRequest& request,
                             const Segments& segments) const override {
    if (segments.resized()) {
      return std::nullopt;
    }

    RewriterInterface::ResizeSegmentsRequest resize_request = {
        .segment_index = segment_index_,
        .segment_sizes = segment_sizes_,
    };
    return resize_request;
  }

 private:
  size_t segment_index_ = 0;
  std::array<uint8_t, 8> segment_sizes_ = {0, 0, 0, 0, 0, 0, 0, 0};
};

ConversionRequest ConvReq(absl::string_view key,
                          ConversionRequest::RequestType request_type) {
  composer::Composer composer;
  composer.SetPreeditTextForTestOnly(key);
  return ConversionRequestBuilder()
      .SetComposer(composer)
      .SetRequestType(request_type)
      .Build();
}

}  // namespace

class MockPredictor : public mozc::prediction::PredictorInterface {
 public:
  MockPredictor() = default;
  ~MockPredictor() override = default;

  MOCK_METHOD(std::vector<Result>, Predict, (const ConversionRequest&),
              (const, override));
  MOCK_METHOD(std::vector<Result>, Convert, (const ConversionRequest&),
              (const, override));
  MOCK_METHOD(void, Revert, (uint32_t), (override));
  MOCK_METHOD(absl::string_view, GetPredictorName, (), (const, override));
  MOCK_METHOD(void, CommitContext, (const ConversionRequest&),
              (const, override));
  MOCK_METHOD(bool, AddHistoryEntry,
              (absl::string_view key, absl::string_view value), (override));
};

class MockRewriter : public RewriterInterface {
 public:
  MockRewriter() = default;
  ~MockRewriter() override = default;

  MOCK_METHOD(bool, Rewrite, (const ConversionRequest&, Segments*),
              (const, override));
  MOCK_METHOD(void, Revert, (const Segments&), (override));
};

class ConverterTest : public testing::TestWithTempUserProfile {
 protected:
  enum PredictorType {
    STUB_PREDICTOR,
    DEFAULT_PREDICTOR,
    MOBILE_PREDICTOR,
  };

  struct UserDefinedEntry {
    const std::string key;
    const std::string value;
    const user_dictionary::UserDictionary::PosType pos;
    UserDefinedEntry(absl::string_view k, absl::string_view v,
                     user_dictionary::UserDictionary::PosType p)
        : key(k), value(v), pos(p) {}
  };

  // Returns initialized predictor for the given type.
  // |converter| will be initialized using predictor pointer, but predictor need
  // the pointer for |converter| for initializing. Prease see
  // mozc/engine/engine.cc for details. Caller should manage the ownership.
  std::unique_ptr<PredictorInterface> CreatePredictor(
      const engine::Modules& modules, PredictorType predictor_type,
      const ConverterInterface& converter,
      const ImmutableConverterInterface& immutable_converter) {
    if (predictor_type == STUB_PREDICTOR) {
      return std::make_unique<StubPredictor>();
    }
    return std::make_unique<prediction::Predictor>(modules, converter,
                                                   immutable_converter);
  }

  // Initializes Converter with mock data set using given |user_dictionary|.
  std::unique_ptr<Converter> CreateConverter(
      std::unique_ptr<engine::Modules> modules,
      std::unique_ptr<RewriterInterface> rewriter,
      PredictorType predictor_type) {
    return std::make_unique<Converter>(
        std::move(modules),
        [&](const engine::Modules& modules) {
          return std::make_unique<ImmutableConverter>(modules);
        },
        [&](const engine::Modules& modules, const ConverterInterface& converter,
            const ImmutableConverterInterface& immutable_converter) {
          return CreatePredictor(modules, predictor_type, converter,
                                 immutable_converter);
        },
        [&](const engine::Modules& modules) { return std::move(rewriter); });
  }

  std::unique_ptr<Converter> CreateConverter(
      std::unique_ptr<RewriterInterface> rewriter,
      PredictorType predictor_type) {
    absl::StatusOr<std::unique_ptr<engine::Modules>> modules =
        engine::Modules::Create(std::make_unique<testing::MockDataManager>());
    CHECK_OK(modules);
    return CreateConverter(*std::move(modules), std::move(rewriter),
                           predictor_type);
  }

  std::unique_ptr<Converter> CreateStubbedConverter() {
    return CreateConverter(std::make_unique<StubRewriter>(), STUB_PREDICTOR);
  }

  std::unique_ptr<Converter> CreateConverterWithUserDefinedEntries(
      absl::Span<const UserDefinedEntry> user_defined_entries,
      PredictorType predictor_type) {
    auto data_manager = std::make_unique<testing::MockDataManager>();

    auto pos_matcher = std::make_unique<dictionary::PosMatcher>(
        data_manager->GetPosMatcherData());
    auto user_pos = make_unique_from_tuples<dictionary::UserPos>(
        data_manager->GetUserPosData());
    auto user_dictionary = make_unique_from_tuples<dictionary::UserDictionary>(
        std::move(user_pos), *pos_matcher);
    {
      user_dictionary::UserDictionaryStorage storage;
      user_dictionary::UserDictionary* dictionary = storage.add_dictionaries();
      for (const UserDefinedEntry& user_entry : user_defined_entries) {
        UserEntry* entry = dictionary->add_entries();
        entry->set_key(user_entry.key);
        entry->set_value(user_entry.value);
        entry->set_pos(user_entry.pos);
      }
      user_dictionary->Load(storage);
    }

    absl::StatusOr<std::unique_ptr<engine::Modules>> modules =
        engine::ModulesPresetBuilder()
            .PresetPosMatcher(std::move(pos_matcher))
            .PresetUserDictionary(std::move(user_dictionary))
            .Build(std::move(data_manager));
    CHECK_OK(modules);

    return CreateConverter(*std::move(modules),
                           std::make_unique<StubRewriter>(), predictor_type);
  }

  std::unique_ptr<Engine> CreateEngine() {
    absl::StatusOr<std::unique_ptr<Engine>> engine =
        Engine::CreateEngine(std::make_unique<testing::MockDataManager>());
    CHECK_OK(engine);
    return *std::move(engine);
  }

  bool FindCandidateByValue(absl::string_view value,
                            const Segment& segment) const {
    for (size_t i = 0; i < segment.candidates_size(); ++i) {
      if (segment.candidate(i).value == value) {
        return true;
      }
    }
    return false;
  }

  int GetCandidateIndexByValue(absl::string_view value,
                               const Segment& segment) const {
    for (size_t i = 0; i < segment.candidates_size(); ++i) {
      if (segment.candidate(i).value == value) {
        return i;
      }
    }
    return -1;  // not found
  }

  const commands::Request& default_request() const { return default_request_; }

 private:
  const commands::Request default_request_;
};

// test for issue:2209644
// just checking whether this causes segmentation fault or not.
// TODO(toshiyuki): make dictionary mock and test strictly.
TEST_F(ConverterTest, CanConvertTest) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  {
    Segments segments;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("-", ConversionRequest::CONVERSION), &segments));
  }
  {
    Segments segments;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("おきておきて", ConversionRequest::CONVERSION), &segments));
  }
}

TEST_F(ConverterTest, ConvertTest) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);

  Segments segments;
  {
    ConversionRequest convreq =
        ConvReq("ぐうぐる", ConversionRequest::CONVERSION);
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);

    const int index =
        GetCandidateIndexByValue("Google", segments.conversion_segment(0));
    ASSERT_NE(index, -1);
    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, index));
    converter->FinishConversion(convreq, &segments);
  }
  {
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("ぐーぐる", ConversionRequest::CONVERSION), &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);

    const int index =
        GetCandidateIndexByValue("Google", segments.conversion_segment(0));
    ASSERT_NE(index, -1);
    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, index));
  }
}

// Confirm that user dictionary words with alphabet keys are generated
// after an alphabet history segment (Issue #1598).
TEST_F(ConverterTest, UserDictionaryAlphabetKeyAfterAlphabetHistory) {
  const std::vector<UserDefinedEntry> user_entries = {
      {"tyksk", "着席", user_dictionary::UserDictionary::NOUN},
      {"tz", "地図", user_dictionary::UserDictionary::NOUN},
      {"tz", "徳泉", user_dictionary::UserDictionary::NOUN},
  };
  std::unique_ptr<Converter> converter =
      CreateConverterWithUserDefinedEntries(user_entries, STUB_PREDICTOR);
  ASSERT_NE(converter, nullptr);

  Segments segments;
  // Scenario 1: Commit an alphabet word, then convert an alphabet-keyed user
  // word.
  {
    ConversionRequest convreq = ConvReq("test", ConversionRequest::CONVERSION);
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, 0));
    converter->FinishConversion(convreq, &segments);
  }
  {
    ConversionRequest convreq = ConvReq("tyksk", ConversionRequest::CONVERSION);
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("着席", segments.conversion_segment(0)));
    converter->CancelConversion(&segments);
  }

  // Scenario 2: Commit an alphabet-keyed user word, then convert another.
  segments.Clear();
  {
    ConversionRequest convreq = ConvReq("tz", ConversionRequest::CONVERSION);
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    const int index =
        GetCandidateIndexByValue("地図", segments.conversion_segment(0));
    ASSERT_NE(index, -1);
    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, index));
    converter->FinishConversion(convreq, &segments);
  }
  {
    ConversionRequest convreq = ConvReq("tz", ConversionRequest::CONVERSION);
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("徳泉", segments.conversion_segment(0)));
  }
}

namespace {
std::string ContextAwareConvert(absl::string_view first_key,
                                absl::string_view first_value,
                                absl::string_view second_key) {
  auto engine_or = MockDataEngineFactory::Create();
  CHECK_OK(engine_or);
  std::unique_ptr<Engine> engine = *std::move(engine_or);
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(
      ConvReq(first_key, ConversionRequest::CONVERSION), &segments));

  std::string converted;
  int segment_num = 0;
  while (true) {
    int position = -1;
    for (size_t i = 0; i < segments.segment(segment_num).candidates_size();
         ++i) {
      absl::string_view value =
          segments.segment(segment_num).candidate(i).value;
      if (first_value.substr(converted.size(), value.size()) == value) {
        position = static_cast<int>(i);
        converted += value;
        break;
      }
    }

    if (position < 0) {
      break;
    }

    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, position))
        << first_value;

    ++segment_num;

    if (first_value == converted) {
      break;
    }
  }
  EXPECT_EQ(first_value, converted) << first_value;
  // TODO(team): Use StartConversionForRequest instead of StartConversion.
  const ConversionRequest default_request;
  converter->FinishConversion(default_request, &segments);
  EXPECT_TRUE(converter->StartConversion(
      ConvReq(second_key, ConversionRequest::CONVERSION), &segments));
  EXPECT_EQ(segments.segments_size(), segment_num + 1);

  return segments.segment(segment_num).candidate(0).value;
}
}  // namespace

TEST_F(ConverterTest, ContextAwareConversionTest) {
  // Desirable context aware conversions
  EXPECT_EQ(ContextAwareConvert("きき", "危機", "いっぱつ"), "一髪");

  EXPECT_EQ(ContextAwareConvert("きょうと", "京都", "だい"), "大");
  EXPECT_EQ(ContextAwareConvert("きき", "危機", "かん"), "感");

  EXPECT_EQ(ContextAwareConvert("いのうえ", "井上", "ようすい"), "陽水");

  // Undesirable context aware conversions
  EXPECT_NE(ContextAwareConvert("19じ", "19時", "しゅうごう"), "宗号");

  EXPECT_NE(ContextAwareConvert("の", "の", "なまえ"), "な前");

  EXPECT_NE(ContextAwareConvert("の", "の", "しりょう"), "し料");

  EXPECT_NE(ContextAwareConvert("ぼくと", "僕と", "しらいさん"), "し礼賛");
}

TEST_F(ConverterTest, CommitSegmentValue) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;

  {
    // Prepare a segment, with candidates "1" and "2";
    Segment* segment = segments.add_segment();
    segment->add_candidate()->value = "1";
    segment->add_candidate()->value = "2";
  }
  {
    // Prepare a segment, with candidates "3" and "4";
    Segment* segment = segments.add_segment();
    segment->add_candidate()->value = "3";
    segment->add_candidate()->value = "4";
  }
  {
    // Commit the candidate whose value is "2".
    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, 1));
    EXPECT_EQ(segments.segments_size(), 2);
    EXPECT_EQ(segments.history_segments_size(), 0);
    EXPECT_EQ(segments.conversion_segments_size(), 2);
    const Segment& segment = segments.conversion_segment(0);
    EXPECT_EQ(segment.segment_type(), Segment::FIXED_VALUE);
    EXPECT_EQ(segment.candidate(0).value, "2");
    EXPECT_NE(segment.candidate(0).attributes & Attribute::RERANKED, 0);
  }
  {
    // Make the segment SUBMITTED
    segments.mutable_conversion_segment(0)->set_segment_type(
        Segment::SUBMITTED);
    EXPECT_EQ(segments.segments_size(), 2);
    EXPECT_EQ(segments.history_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segments_size(), 1);
  }
  {
    // Commit the candidate whose value is "3".
    EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, 0));
    EXPECT_EQ(segments.segments_size(), 2);
    EXPECT_EQ(segments.history_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    const Segment& segment = segments.conversion_segment(0);
    EXPECT_EQ(segment.segment_type(), Segment::FIXED_VALUE);
    EXPECT_EQ(segment.candidate(0).value, "3");
    EXPECT_EQ(segment.candidate(0).attributes & Attribute::RERANKED, 0);
  }
}

TEST_F(ConverterTest, CommitSegmentValueWithMultiSegmentCandidate) {
  auto engine_status = MockDataEngineFactory::Create();
  ASSERT_OK(engine_status);
  std::unique_ptr<Engine> engine = *std::move(engine_status);
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;

  segments.set_max_history_segments_size(3);
  {
    Segment* segment = segments.add_segment();
    segment->set_key("わたしの");
    converter::Candidate* cand0 = segment->add_candidate();
    cand0->value = "私の";
    cand0->key = "わたしの";
    converter::Candidate* cand1 = segment->add_candidate();
    cand1->value = "私の名前は";
    cand1->key = "わたしのなまえは";
    cand1->converted_segment_count = 2;
  }
  {
    Segment* segment = segments.add_segment();
    segment->set_key("なまえは");
    converter::Candidate* cand = segment->add_candidate();
    cand->value = "名前は";
    cand->key = "なまえは";
  }
  {
    Segment* segment = segments.add_segment();
    segment->set_key("なかのです");
    converter::Candidate* cand = segment->add_candidate();
    cand->value = "中野です";
    cand->key = "なかのです";
  }

  ASSERT_EQ(segments.conversion_segments_size(), 3);

  // CommitSegmentValue selects the multi-segment candidate without
  // destructively erasing segments.
  EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, 1));
  EXPECT_EQ(segments.conversion_segments_size(), 3);
  const Segment& seg0 = segments.conversion_segment(0);
  EXPECT_EQ(seg0.segment_type(), Segment::FIXED_VALUE);
  EXPECT_EQ(seg0.candidate(0).value, "私の名前は");
  EXPECT_EQ(seg0.candidate(0).converted_segment_count, 2);

  // FinishConversion merges the multi-segment candidate segments into history
  // segments.
  const ConversionRequest request =
      ConversionRequestBuilder()
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();
  converter->FinishConversion(request, &segments);
  EXPECT_EQ(segments.conversion_segments_size(), 0);
  EXPECT_EQ(segments.history_segments_size(), 2);
  const Segment& final_seg0 = segments.history_segment(0);
  EXPECT_EQ(final_seg0.key(), "わたしのなまえは");
  EXPECT_EQ(final_seg0.candidate(0).value, "私の名前は");
  const Segment& final_seg1 = segments.history_segment(1);
  EXPECT_EQ(final_seg1.key(), "なかのです");
  EXPECT_EQ(final_seg1.candidate(0).value, "中野です");
}

TEST_F(ConverterTest, CommitSegments) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;

  // History segment.
  {
    Segment* segment = segments.add_segment();
    segment->set_key("あした");
    segment->set_segment_type(Segment::HISTORY);
    Candidate* candidate = segment->add_candidate();
    candidate->key = "あした";
    candidate->value = "今日";
  }

  {
    Segment* segment = segments.add_segment();
    segment->set_key("かつこうに");
    Candidate* candidate = segment->add_candidate();
    candidate->value = "学校に";
    candidate->key = "がっこうに";
  }

  {
    Segment* segment = segments.add_segment();
    segment->set_key("いく");
    Candidate* candidate = segment->add_candidate();
    candidate->value = "行く";
    candidate->key = "いく";
  }

  // Test "CommitFirstSegment" feature.
  {
    // Commit 1st segment.
    std::vector<size_t> index_list;
    index_list.push_back(0);
    ASSERT_TRUE(converter->CommitSegments(&segments, index_list));

    EXPECT_EQ(segments.history_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.history_segment(0).segment_type(), Segment::HISTORY);
    EXPECT_EQ(segments.history_segment(1).segment_type(), Segment::SUBMITTED);
  }

  // Reset the test data.
  segments.mutable_history_segment(1)->set_segment_type(Segment::FREE);

  // Test "CommitHeadToFocusedSegment" feature.
  {
    // Commit 1st and 2nd segments.
    std::vector<size_t> index_list;
    index_list.push_back(0);
    index_list.push_back(0);
    ASSERT_TRUE(converter->CommitSegments(&segments, index_list));

    EXPECT_EQ(segments.history_segments_size(), 3);
    EXPECT_EQ(segments.conversion_segments_size(), 0);
    EXPECT_EQ(segments.history_segment(0).segment_type(), Segment::HISTORY);
    EXPECT_EQ(segments.history_segment(1).segment_type(), Segment::SUBMITTED);
    EXPECT_EQ(segments.history_segment(2).segment_type(), Segment::SUBMITTED);
  }
}

TEST_F(ConverterTest, CommitSegmentsMultiSegment) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;

  // Segment 0: multi-segment candidate covering segments 0 and 1.
  {
    Segment* segment = segments.add_segment();
    segment->set_key("ここでは");
    Candidate* candidate = segment->add_candidate();
    candidate->key = "ここではきものを";
    candidate->value = "ここで履物を";
    candidate->converted_segment_count = 2;
  }
  // Segment 1: covered by segment 0's multi-segment candidate.
  {
    Segment* segment = segments.add_segment();
    segment->set_key("きものを");
    Candidate* candidate = segment->add_candidate();
    candidate->key = "きものを";
    candidate->value = "着物を";
  }
  // Segment 2: uncovered segment.
  {
    Segment* segment = segments.add_segment();
    segment->set_key("ぬぐ");
    Candidate* candidate = segment->add_candidate();
    candidate->key = "ぬぐ";
    candidate->value = "脱ぐ";
  }

  ASSERT_TRUE(converter->CommitSegments(&segments, {0}));

  EXPECT_EQ(segments.history_segments_size(), 1);
  EXPECT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.history_segment(0).segment_type(), Segment::SUBMITTED);
  EXPECT_EQ(segments.history_segment(0).key(), "ここではきものを");
  EXPECT_EQ(segments.history_segment(0).candidate(0).value, "ここで履物を");
  EXPECT_EQ(segments.history_segment(0).candidate(0).converted_segment_count,
            1);
  EXPECT_EQ(segments.conversion_segment(0).key(), "ぬぐ");
  EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "脱ぐ");
}

TEST_F(ConverterTest, CommitPartialSuggestionSegmentValue) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;

  {
    // Prepare a segment, with candidates "1" and "2";
    Segment* segment = segments.add_segment();
    segment->add_candidate()->value = "1";
    segment->add_candidate()->value = "2";
  }
  {
    // Prepare a segment, with candidates "3" and "4";
    Segment* segment = segments.add_segment();
    segment->add_candidate()->value = "3";
    segment->add_candidate()->value = "4";
  }
  {
    // Commit the candidate whose value is "2".
    EXPECT_TRUE(converter->CommitPartialSuggestionSegmentValue(
        &segments, 0, 1, "left2", "right2"));
    EXPECT_EQ(segments.segments_size(), 3);
    EXPECT_EQ(segments.history_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segments_size(), 2);
    {
      // The tail segment of the history segments uses
      // CommitPartialSuggestionSegmentValue's |current_segment_key| parameter
      // and contains original value.
      const Segment& segment =
          segments.history_segment(segments.history_segments_size() - 1);
      EXPECT_EQ(segment.segment_type(), Segment::SUBMITTED);
      EXPECT_EQ(segment.candidate(0).value, "2");
      EXPECT_EQ(segment.key(), "left2");
      EXPECT_NE(segment.candidate(0).attributes & Attribute::RERANKED, 0);
    }
    {
      // The head segment of the conversion segments uses |new_segment_key|.
      const Segment& segment = segments.conversion_segment(0);
      EXPECT_EQ(segment.segment_type(), Segment::FREE);
      EXPECT_EQ(segment.key(), "right2");
    }
  }
}

TEST_F(ConverterTest, CandidateKeyTest) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;
  EXPECT_TRUE(converter->StartConversion(
      ConvReq("わたしは", ConversionRequest::CONVERSION), &segments));
  EXPECT_EQ(segments.segments_size(), 1);
  EXPECT_EQ(segments.segment(0).candidate(0).key, "わたしは");
  EXPECT_EQ(segments.segment(0).candidate(0).content_key, "わたし");
}

TEST_F(ConverterTest, Regression3437022) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  Segments segments;

  const std::string kKey1 = "けいたい";
  const std::string kKey2 = "でんわ";

  const std::string kValue1 = "携帯";
  const std::string kValue2 = "電話";

  {
    // Make sure convert result is one segment
    EXPECT_TRUE(converter->StartConversion(
        ConvReq(kKey1 + kKey2, ConversionRequest::CONVERSION), &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value,
              kValue1 + kValue2);
  }
  {
    // Make sure we can convert first part
    segments.Clear();
    EXPECT_TRUE(converter->StartConversion(
        ConvReq(kKey1, ConversionRequest::CONVERSION), &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kValue1);
  }
  {
    // Make sure we can convert last part
    segments.Clear();
    EXPECT_TRUE(converter->StartConversion(
        ConvReq(kKey2, ConversionRequest::CONVERSION), &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kValue2);
  }

  segments.Clear();

  // Add compound entry to suppression dictionary
  {
    user_dictionary::UserDictionaryStorage storage;
    UserEntry* entry = storage.add_dictionaries()->add_entries();
    entry->set_key(kKey1 + kKey2);
    entry->set_value(kValue1 + kValue2);
    entry->set_pos(user_dictionary::UserDictionary::SUPPRESSION_WORD);
    engine->GetModulesForTesting().GetUserDictionary().Load(storage);
    EXPECT_TRUE(engine->GetModulesForTesting()
                    .GetUserDictionary()
                    .HasSuppressedEntries());
  }

  EXPECT_TRUE(converter->StartConversion(
      ConvReq(kKey1 + kKey2, ConversionRequest::CONVERSION), &segments));

  int rest_size = 0;
  for (const Segment& segment : segments.conversion_segments().drop(1)) {
    rest_size += Util::CharsLen(segment.candidate(0).key);
  }

  // Expand segment so that the entire part will become one segment
  if (rest_size > 0) {
    const ConversionRequest default_request;
    EXPECT_TRUE(
        converter->ResizeSegment(&segments, default_request, 0, rest_size));
  }

  EXPECT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_NE(segments.conversion_segment(0).candidate(0).value,
            kValue1 + kValue2);
}

TEST_F(ConverterTest, CompletePosIds) {
  absl::string_view kTestKeys[] = {
      "きょうと", "いきます",         "うつくしい",
      "おおきな", "いっちゃわないね", "わたしのなまえはなかのです",
  };

  std::unique_ptr<Converter> converter = CreateStubbedConverter();
  ConverterTestPeer converter_peer(*converter);
  for (size_t i = 0; i < std::size(kTestKeys); ++i) {
    Segments segments;
    Segment* seg = segments.add_segment();
    seg->set_key(kTestKeys[i]);
    seg->set_segment_type(Segment::FREE);
    const ConversionRequest request =
        ConversionRequestBuilder()
            .SetOptions({
                .request_type = ConversionRequest::PREDICTION,
                .max_conversion_candidates_size = 20,
            })
            .Build();
    CHECK(
        converter->immutable_converter().Convert(request.options(), &segments));
    const int lid = segments.segment(0).candidate(0).lid;
    const int rid = segments.segment(0).candidate(0).rid;
    Candidate candidate;
    candidate.value = segments.segment(0).candidate(0).value;
    candidate.key = segments.segment(0).candidate(0).key;
    candidate.lid = 0;
    candidate.rid = 0;
    converter_peer.CompletePosIds(&candidate);
    EXPECT_EQ(candidate.lid, lid);
    EXPECT_EQ(candidate.rid, rid);
    EXPECT_NE(candidate.lid, 0);
    EXPECT_NE(candidate.rid, 0);
  }

  {
    Candidate candidate;
    candidate.key = "test";
    candidate.value = "test";
    candidate.lid = 10;
    candidate.rid = 11;
    converter_peer.CompletePosIds(&candidate);
    EXPECT_EQ(candidate.lid, 10);
    EXPECT_EQ(candidate.rid, 11);
  }
}

TEST_F(ConverterTest, Regression3046266) {
  // Shouldn't correct nodes at the beginning of a sentence.
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  Segments segments;

  // Can be any string that has "ん" at the end
  constexpr absl::string_view kKey1 = "かん";

  // Can be any string that has a vowel at the beginning
  constexpr absl::string_view kKey2 = "あか";

  constexpr absl::string_view kValueNotExpected = "中";

  EXPECT_TRUE(converter->StartConversion(
      ConvReq(kKey1, ConversionRequest::CONVERSION), &segments));
  EXPECT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_TRUE(converter->CommitSegmentValue(&segments, 0, 0));

  // TODO(team): Use StartConversionForRequest instead of StartConversion.
  const ConversionRequest default_request;
  converter->FinishConversion(default_request, &segments);

  EXPECT_TRUE(converter->StartConversion(
      ConvReq(kKey2, ConversionRequest::CONVERSION), &segments));
  EXPECT_EQ(segments.conversion_segments_size(), 1);
  const Segment& segment = segments.conversion_segment(0);
  for (size_t i = 0; i < segment.candidates_size(); ++i) {
    EXPECT_NE(segment.candidate(i).value, kValueNotExpected);
  }
}

TEST_F(ConverterTest, Regression5502496) {
  // Make sure key correction works for the first word of a sentence.
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  Segments segments;

  constexpr absl::string_view kKey = "みんあ";
  constexpr absl::string_view kValueExpected = "みんな";

  EXPECT_TRUE(converter->StartConversion(
      ConvReq(kKey, ConversionRequest::CONVERSION), &segments));
  EXPECT_EQ(segments.conversion_segments_size(), 1);
  const Segment& segment = segments.conversion_segment(0);
  bool found = false;
  for (size_t i = 0; i < segment.candidates_size(); ++i) {
    if (segment.candidate(i).value == kValueExpected) {
      found = true;
    }
  }
  EXPECT_TRUE(found);
}

TEST_F(ConverterTest, StartSuggestion) {
  commands::Request client_request;
  client_request.set_mixed_conversion(true);

  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);

  const std::string kShi = "し";

  auto table = std::make_shared<composer::Table>();
  table->AddRule("si", kShi, "");
  table->AddRule("shi", kShi, "");
  config::Config config;

  {
    composer::Composer composer(table, client_request, config);

    composer.InsertCharacter("shi");

    ConversionRequest::Options options = {.request_type =
                                              ConversionRequest::SUGGESTION};
    Segments segments;
    const ConversionRequest request =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequestView(client_request)
            .SetConfigView(config)
            .SetHistoryResult(HistorySegmentsToResult(segments))
            .SetOptions(std::move(options))
            .Build();

    EXPECT_TRUE(converter->StartPrediction(request, &segments));
    EXPECT_EQ(segments.segments_size(), 1);
    ASSERT_TRUE(segments.segment(0).meta_candidates_size() >=
                transliteration::HALF_ASCII);
    EXPECT_EQ(
        segments.segment(0).meta_candidate(transliteration::HALF_ASCII).value,
        "shi");
  }

  {
    composer::Composer composer(table, client_request, config);

    composer.InsertCharacter("si");

    ConversionRequest::Options options = {.request_type =
                                              ConversionRequest::SUGGESTION};
    Segments segments;
    const ConversionRequest request =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequestView(client_request)
            .SetConfigView(config)
            .SetHistoryResult(HistorySegmentsToResult(segments))
            .SetOptions(std::move(options))
            .Build();

    EXPECT_TRUE(converter->StartPrediction(request, &segments));
    EXPECT_EQ(segments.segments_size(), 1);
    ASSERT_TRUE(segments.segment(0).meta_candidates_size() >=
                transliteration::HALF_ASCII);
    EXPECT_EQ(
        segments.segment(0).meta_candidate(transliteration::HALF_ASCII).value,
        "si");
  }
}

TEST_F(ConverterTest, StartPartialPrediction) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;
  EXPECT_TRUE(converter->StartPrediction(
      ConvReq("わたしは", ConversionRequest::PARTIAL_PREDICTION), &segments));
  EXPECT_EQ(segments.segments_size(), 1);
  EXPECT_EQ(segments.segment(0).candidate(0).value, "私は");
  EXPECT_EQ(segments.segment(0).candidate(0).content_value, "私");
  EXPECT_EQ(segments.segment(0).candidate(0).key, "わたしは");
  EXPECT_EQ(segments.segment(0).candidate(0).content_key, "わたし");
}

TEST_F(ConverterTest, StartPartialSuggestion) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;
  EXPECT_TRUE(converter->StartPrediction(
      ConvReq("わたしは", ConversionRequest::PARTIAL_SUGGESTION), &segments));
  EXPECT_EQ(segments.segments_size(), 1);
  EXPECT_EQ(segments.segment(0).candidate(0).value, "私は");
  EXPECT_EQ(segments.segment(0).candidate(0).content_value, "私");
  EXPECT_EQ(segments.segment(0).candidate(0).key, "わたしは");
  EXPECT_EQ(segments.segment(0).candidate(0).content_key, "わたし");
}

TEST_F(ConverterTest, StartPartialPredictionMobile) {
  std::unique_ptr<Engine> engine = CreateEngine();
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;
  EXPECT_TRUE(converter->StartPrediction(
      ConvReq("わたしは", ConversionRequest::PARTIAL_PREDICTION), &segments));
  EXPECT_EQ(segments.segments_size(), 1);
  EXPECT_EQ(segments.segment(0).candidate(0).value, "私は");
  EXPECT_EQ(segments.segment(0).candidate(0).content_value, "私");
  EXPECT_EQ(segments.segment(0).candidate(0).key, "わたしは");
  EXPECT_EQ(segments.segment(0).candidate(0).content_key, "わたし");
}

TEST_F(ConverterTest, StartPartialSuggestionMobile) {
  std::unique_ptr<Engine> engine = CreateEngine();
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  Segments segments;
  EXPECT_TRUE(converter->StartPrediction(
      ConvReq("わたしは", ConversionRequest::PARTIAL_SUGGESTION), &segments));
  EXPECT_EQ(segments.segments_size(), 1);
  EXPECT_EQ(segments.segment(0).candidate(0).value, "私は");
  EXPECT_EQ(segments.segment(0).candidate(0).content_value, "私");
  EXPECT_EQ(segments.segment(0).candidate(0).key, "わたしは");
  EXPECT_EQ(segments.segment(0).candidate(0).content_key, "わたし");
}

TEST_F(ConverterTest, MaybeSetConsumedKeySizeToSegment) {
  const size_t consumed_key_size = 5;
  const size_t original_consumed_key_size = 10;

  Segment segment;
  // 1st candidate without PARTIALLY_KEY_CONSUMED
  segment.push_back_candidate();
  // 2nd candidate with PARTIALLY_KEY_CONSUMED
  Candidate* candidate2 = segment.push_back_candidate();
  candidate2->attributes |= Attribute::PARTIALLY_KEY_CONSUMED;
  candidate2->consumed_key_size = original_consumed_key_size;
  // 1st meta candidate without PARTIALLY_KEY_CONSUMED
  segment.add_meta_candidate();
  // 2nd meta candidate with PARTIALLY_KEY_CONSUMED
  Candidate* meta_candidate2 = segment.add_meta_candidate();
  meta_candidate2->attributes |= Attribute::PARTIALLY_KEY_CONSUMED;
  meta_candidate2->consumed_key_size = original_consumed_key_size;

  ConverterTestPeer::MaybeSetConsumedKeySizeToSegment(consumed_key_size,
                                                      &segment);
  EXPECT_NE(
      (segment.candidate(0).attributes & Attribute::PARTIALLY_KEY_CONSUMED), 0);
  EXPECT_EQ(segment.candidate(0).consumed_key_size, consumed_key_size);
  EXPECT_NE(
      (segment.candidate(1).attributes & Attribute::PARTIALLY_KEY_CONSUMED), 0);
  EXPECT_EQ(segment.candidate(1).consumed_key_size, original_consumed_key_size);
  EXPECT_NE((segment.meta_candidate(0).attributes &
             Attribute::PARTIALLY_KEY_CONSUMED),
            0);
  EXPECT_EQ(segment.meta_candidate(0).consumed_key_size, consumed_key_size);
  EXPECT_NE((segment.meta_candidate(1).attributes &
             Attribute::PARTIALLY_KEY_CONSUMED),
            0);
  EXPECT_EQ(segment.meta_candidate(1).consumed_key_size,
            original_consumed_key_size);
}

TEST_F(ConverterTest, PredictSetKey) {
  constexpr absl::string_view kPredictionKey = "prediction key";
  constexpr absl::string_view kPredictionKey2 = "prediction key2";
  // Tests whether SetKey method is called or not.
  struct TestData {
    // Input conditions.
    const std::optional<absl::string_view> key;  // Input key presence.

    const bool expect_set_key_is_called;
  };
  const TestData test_data_list[] = {
      {std::nullopt, true},
      {kPredictionKey2, true},
      // This is the only case where SetKey() is not called; because SetKey is
      // not requested in Request and Segments' key is already present.
      {kPredictionKey, false},
  };

  std::unique_ptr<Converter> converter = CreateStubbedConverter();

  for (const TestData& test_data : test_data_list) {
    Segments segments;
    int orig_candidates_size = 0;
    if (test_data.key) {
      Segment* seg = segments.add_segment();
      seg->set_key(*test_data.key);
      PushBackCandidate(*test_data.key, *seg);
      orig_candidates_size = seg->candidates_size();
    }

    composer::Composer composer;
    composer.SetPreeditTextForTestOnly(kPredictionKey);
    const ConversionRequest request =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetHistoryResult(HistorySegmentsToResult(segments))
            .SetRequestType(ConversionRequest::PREDICTION)
            .Build();
    ASSERT_TRUE(converter->StartPrediction(request, &segments));

    ASSERT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).key(), kPredictionKey);
    if (test_data.expect_set_key_is_called) {
      // If SetKey is called, the segment has only one candidate populated by
      // StubPredictor.
      EXPECT_EQ(segments.conversion_segment(0).candidates_size(), 1);
    } else {
      // If SetKey is not called, the segment has been added one candidate by
      // StubPredictor.
      const int expected_candidates_size = orig_candidates_size + 1;
      EXPECT_EQ(segments.conversion_segment(0).candidates_size(),
                expected_candidates_size);
    }
  }
}

// An action that invokes a DictionaryInterface::Callback with the token whose
// key and value is set to the given ones.
struct InvokeCallbackWithUserDictionaryToken {
  template <class T>
  void operator()(T, DictionaryInterface::Callback* callback) {
    const Token token(key, value, MockDictionary::kDefaultCost,
                      MockDictionary::kDefaultPosId,
                      MockDictionary::kDefaultPosId, Token::USER_DICTIONARY);
    callback->OnToken(key, key, token);
  }

  std::string key;
  std::string value;
};

TEST_F(ConverterTest, VariantExpansionForSuggestion) {
  // Create Converter with mock user dictionary
  auto mock_user_dictionary = std::make_unique<MockUserDictionary>();
  EXPECT_CALL(*mock_user_dictionary, LookupPredictive(_, _)).Times(AnyNumber());
  EXPECT_CALL(*mock_user_dictionary, LookupPredictive(StrEq("てすと"), _))
      .WillRepeatedly(InvokeCallbackWithUserDictionaryToken{"てすと", "<>!?"});

  EXPECT_CALL(*mock_user_dictionary, LookupPrefix(_, _)).Times(AnyNumber());
  EXPECT_CALL(*mock_user_dictionary, LookupPrefix(StrEq("てすとの"), _))
      .WillRepeatedly(InvokeCallbackWithUserDictionaryToken{"てすと", "<>!?"});

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::ModulesPresetBuilder()
          .PresetUserDictionary(std::move(mock_user_dictionary))
          .Build(std::make_unique<testing::MockDataManager>()));

  Converter converter(
      std::move(modules),
      [&](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [](const engine::Modules& modules, const ConverterInterface& converter,
         const ImmutableConverterInterface& immutable_converter) {
        return std::make_unique<prediction::Predictor>(modules, converter,
                                                       immutable_converter);
      },
      [](const engine::Modules& modules) {
        return std::make_unique<Rewriter>(modules);
      });

  Segments segments;
  {
    // Dictionary suggestion
    EXPECT_TRUE(converter.StartPrediction(
        ConvReq("てすと", ConversionRequest::SUGGESTION), &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_LE(1, segments.conversion_segment(0).candidates_size());
    EXPECT_TRUE(FindCandidateByValue("<>!?", segments.conversion_segment(0)));
    EXPECT_FALSE(
        FindCandidateByValue("＜＞！？", segments.conversion_segment(0)));
  }
  {
    // Realtime conversion
    segments.Clear();
    EXPECT_TRUE(converter.StartPrediction(
        ConvReq("てすとの", ConversionRequest::SUGGESTION), &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_LE(1, segments.conversion_segment(0).candidates_size());
    EXPECT_TRUE(FindCandidateByValue("<>!?の", segments.conversion_segment(0)));
    EXPECT_FALSE(
        FindCandidateByValue("＜＞！？の", segments.conversion_segment(0)));
  }
}

TEST_F(ConverterTest, ComposerKeySelection) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  auto table = std::make_shared<composer::Table>();
  config::Config config;
  {
    Segments segments;
    composer::Composer composer(table, default_request(), config);
    composer.InsertCharacterPreedit("わたしh");

    const ConversionRequest request =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetHistoryResult(HistorySegmentsToResult(segments))
            .SetOptions(
                {.composer_key_selection = ConversionRequest::CONVERSION_KEY})
            .Build();
    ASSERT_TRUE(converter->StartConversion(request, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "私");
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, "h");
  }
  {
    Segments segments;
    composer::Composer composer(table, default_request(), config);
    composer.InsertCharacterPreedit("わたしh");

    const ConversionRequest request =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetHistoryResult(HistorySegmentsToResult(segments))
            .SetOptions(
                {.composer_key_selection = ConversionRequest::PREDICTION_KEY})
            .Build();
    ASSERT_TRUE(converter->StartConversion(request, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "私");
  }
}

TEST_F(ConverterTest, SuppressionDictionaryForRewriter) {
  std::unique_ptr<Converter> converter = CreateConverter(
      std::make_unique<InsertPlaceholderWordsRewriter>(), STUB_PREDICTOR);

  engine::Modules& modules = converter->modules();

  // Set up suppression dictionary
  {
    user_dictionary::UserDictionaryStorage storage;
    UserEntry* entry = storage.add_dictionaries()->add_entries();
    entry->set_key("tobefiltered");
    entry->set_value("ToBeFiltered");
    entry->set_pos(user_dictionary::UserDictionary::SUPPRESSION_WORD);
    modules.GetUserDictionary().Load(storage);
    EXPECT_TRUE(modules.GetUserDictionary().HasSuppressedEntries());
  }

  // Convert
  auto table = std::make_shared<composer::Table>();
  config::Config config;
  composer::Composer composer(table, default_request(), config);
  composer.InsertCharacter("placeholder");
  Segments segments;
  const ConversionRequest request =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetHistoryResult(HistorySegmentsToResult(segments))
          .SetConfig(config)
          .Build();
  EXPECT_TRUE(converter->StartConversion(request, &segments));

  // Verify that words inserted by the rewriter is suppressed if its in the
  // suppression_dictionary.
  for (const Segment& segment : segments.conversion_segments()) {
    EXPECT_FALSE(FindCandidateByValue("ToBeFiltered", segment));
    EXPECT_TRUE(FindCandidateByValue("NotToBeFiltered", segment));
  }
}

TEST_F(ConverterTest, EmptyConvertReverseIssue8661091) {
  // This is a test case against b/8661091.
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  Segments segments;
  EXPECT_FALSE(converter->StartReverseConversion(&segments, ""));
}

TEST_F(ConverterTest, StartReverseConversion) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  const std::shared_ptr<const ConverterInterface> converter =
      engine->GetConverter();

  constexpr absl::string_view kHonKanji = "本";
  constexpr absl::string_view kHonHiragana = "ほん";
  constexpr absl::string_view kMuryouKanji = "無料";
  constexpr absl::string_view kMuryouHiragana = "むりょう";
  constexpr absl::string_view kFullWidthSpace = "　";  // full-width space
  {
    // Test for single Kanji character.
    absl::string_view kInput = kHonKanji;
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 1);
    ASSERT_LE(1, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kHonHiragana);
  }
  {
    // Test for multi-Kanji character.
    absl::string_view kInput = kMuryouKanji;
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 1);
    ASSERT_LE(1, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value,
              kMuryouHiragana);
  }
  {
    // Test for multi terms separated by a space.
    const std::string kInput = absl::StrCat(kHonKanji, " ", kMuryouKanji);
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 3);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kHonHiragana);
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, " ");
    ASSERT_LT(0, segments.conversion_segment(2).candidates_size());
    EXPECT_EQ(segments.conversion_segment(2).candidate(0).value,
              kMuryouHiragana);
  }
  {
    // Test for multi terms separated by multiple spaces.
    const std::string kInput = absl::StrCat(kHonKanji, "   ", kMuryouKanji);
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 3);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kHonHiragana);
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, "   ");
    ASSERT_LT(0, segments.conversion_segment(2).candidates_size());
    EXPECT_EQ(segments.conversion_segment(2).candidate(0).value,
              kMuryouHiragana);
  }
  {
    // Test for leading white spaces.
    const std::string kInput = absl::StrCat("  ", kHonKanji);
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 2);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "  ");
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, kHonHiragana);
  }
  {
    // Test for trailing white spaces.
    const std::string kInput = absl::StrCat(kMuryouKanji, "  ");
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 2);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value,
              kMuryouHiragana);
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, "  ");
  }
  {
    // Test for multi terms separated by a full-width space.
    const std::string kInput =
        absl::StrCat(kHonKanji, kFullWidthSpace, kMuryouKanji);
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 3);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kHonHiragana);
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value,
              kFullWidthSpace);
    ASSERT_LT(0, segments.conversion_segment(2).candidates_size());
    EXPECT_EQ(segments.conversion_segment(2).candidate(0).value,
              kMuryouHiragana);
  }
  {
    // Test for multi terms separated by two full-width spaces.
    const std::string kFullWidthSpace2 =
        absl::StrCat(kFullWidthSpace, kFullWidthSpace);
    const std::string kInput =
        absl::StrCat(kHonKanji, kFullWidthSpace2, kMuryouKanji);
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 3);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kHonHiragana);
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value,
              kFullWidthSpace2);
    ASSERT_LT(0, segments.conversion_segment(2).candidates_size());
    EXPECT_EQ(segments.conversion_segment(2).candidate(0).value,
              kMuryouHiragana);
  }
  {
    // Test for multi terms separated by the mix of full- and half-width spaces.
    const std::string kFullWidthSpace2 = absl::StrCat(kFullWidthSpace, " ");
    const std::string kInput =
        absl::StrCat(kHonKanji, kFullWidthSpace2, kMuryouKanji);
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInput));
    ASSERT_EQ(segments.segments_size(), 3);
    ASSERT_LT(0, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kHonHiragana);
    ASSERT_LT(0, segments.conversion_segment(1).candidates_size());
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value,
              kFullWidthSpace2);
    ASSERT_LT(0, segments.conversion_segment(2).candidates_size());
    EXPECT_EQ(segments.conversion_segment(2).candidate(0).value,
              kMuryouHiragana);
  }
  {
    // Test for math expressions; see b/9398304.
    const absl::string_view kInputHalf = "365*24*60*60*1000=";
    Segments segments;
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInputHalf));
    ASSERT_EQ(segments.segments_size(), 1);
    ASSERT_EQ(segments.conversion_segment(0).candidates_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kInputHalf);

    // Test for full-width characters.
    segments.Clear();
    const absl::string_view kInputFull = "３６５＊２４＊６０＊６０＊１０００＝";
    EXPECT_TRUE(converter->StartReverseConversion(&segments, kInputFull));
    ASSERT_EQ(segments.segments_size(), 1);
    ASSERT_EQ(segments.conversion_segment(0).candidates_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, kInputHalf);
  }
}

TEST_F(ConverterTest, ReconstructHistory) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  constexpr absl::string_view kTen = "１０";

  Segments segments;
  EXPECT_TRUE(converter->ReconstructHistory(&segments, kTen));
  EXPECT_EQ(segments.segments_size(), 1);
  const Segment& segment = segments.segment(0);
  EXPECT_EQ(segment.segment_type(), Segment::HISTORY);
  EXPECT_EQ(segment.key(), "10");
  EXPECT_EQ(segment.candidates_size(), 1);
  const Candidate& candidate = segment.candidate(0);
  EXPECT_EQ(candidate.attributes, Attribute::NO_LEARNING);
  EXPECT_EQ(candidate.content_key, "10");
  EXPECT_EQ(candidate.key, "10");
  EXPECT_EQ(candidate.content_value, kTen);
  EXPECT_EQ(candidate.value, kTen);
  EXPECT_NE(candidate.lid, 0);
  EXPECT_NE(candidate.rid, 0);
}

TEST_F(ConverterTest, LimitCandidatesSize) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  auto table = std::make_shared<composer::Table>();
  const config::Config& config = config::ConfigHandler::DefaultConfig();
  mozc::commands::Request request_proto;
  mozc::composer::Composer composer(table, request_proto, config);
  composer.InsertCharacterPreedit("あ");
  Segments segments;
  const ConversionRequest request1 =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetHistoryResult(HistorySegmentsToResult(segments))
          .SetRequest(request_proto)
          .Build();
  ASSERT_TRUE(converter->StartConversion(request1, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  const int original_candidates_size = segments.segment(0).candidates_size();
  const int original_meta_candidates_size =
      segments.segment(0).meta_candidates_size();
  EXPECT_LT(0, original_candidates_size - 1 - original_meta_candidates_size)
      << "original candidates size: " << original_candidates_size
      << ", original meta candidates size: " << original_meta_candidates_size;

  segments.Clear();
  request_proto.set_candidates_size_limit(original_candidates_size - 1);
  const ConversionRequest request2 =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetHistoryResult(HistorySegmentsToResult(segments))
          .Build();
  ASSERT_TRUE(converter->StartConversion(request2, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_GE(original_candidates_size - 1,
            segments.segment(0).candidates_size());
  EXPECT_LE(original_candidates_size - 1 - original_meta_candidates_size,
            segments.segment(0).candidates_size());
  EXPECT_EQ(segments.segment(0).meta_candidates_size(),
            original_meta_candidates_size);

  segments.Clear();
  request_proto.set_candidates_size_limit(0);
  const ConversionRequest request3 =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetHistoryResult(HistorySegmentsToResult(segments))
          .Build();
  ASSERT_TRUE(converter->StartConversion(request3, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.segment(0).candidates_size(), 1);
  EXPECT_EQ(segments.segment(0).meta_candidates_size(),
            original_meta_candidates_size);
}

TEST_F(ConverterTest, UserEntryShouldBePromoted) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  // "哀" is not in the test dictionary
  user_defined_entries.push_back(
      UserDefinedEntry("あい", "哀", UserDictionary::NOUN));

  std::unique_ptr<Converter> converter = CreateConverterWithUserDefinedEntries(
      user_defined_entries, STUB_PREDICTOR);

  {
    Segments segments;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("あい", ConversionRequest::CONVERSION), &segments));
    ASSERT_EQ(segments.conversion_segments_size(), 1);
    ASSERT_LT(1, segments.conversion_segment(0).candidates_size());
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "哀");
  }
}

TEST_F(ConverterTest, UserEntryInMobilePrediction) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  user_defined_entries.push_back(
      UserDefinedEntry("てすと", "google", UserDictionary::NO_POS));

  commands::Request request;
  config::Config config;
  config::ConfigHandler::GetDefaultConfig(&config);
  auto table = std::make_shared<composer::Table>();
  composer::Composer composer(table, request, config);
  request_test_util::FillMobileRequest(&request);

  std::unique_ptr<Converter> converter = CreateConverterWithUserDefinedEntries(
      user_defined_entries, MOBILE_PREDICTOR);

  {
    composer.SetPreeditTextForTestOnly("てすとが");
    ConversionRequest::Options options = {
        .request_type = ConversionRequest::PREDICTION,
    };
    Segments segments;
    const ConversionRequest conversion_request =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequestView(request)
            .SetConfigView(config)
            .SetHistoryResult(HistorySegmentsToResult(segments))
            .SetOptions(std::move(options))
            .Build();
    EXPECT_TRUE(converter->StartPrediction(conversion_request, &segments));
    ASSERT_EQ(segments.segments_size(), 1);
    EXPECT_THAT(segments.segment(0),
                ContainsCandidate(Field(&Candidate::value, StrEq("googleが"))));
  }
}

TEST_F(ConverterTest, UserEntryShouldBePromotedMobilePrediction) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  // "哀" is not in the test dictionary
  user_defined_entries.push_back(
      UserDefinedEntry("あい", "哀", UserDictionary::NOUN));

  std::unique_ptr<Converter> converter = CreateConverterWithUserDefinedEntries(
      user_defined_entries, MOBILE_PREDICTOR);

  {
    Segments segments;
    EXPECT_TRUE(converter->StartPrediction(
        ConvReq("あい", ConversionRequest::PREDICTION), &segments));
    ASSERT_EQ(segments.conversion_segments_size(), 1);
    ASSERT_LT(1, segments.conversion_segment(0).candidates_size());

    // "哀" should be the top result for the key "あい".
    int first_ai_index = -1;
    for (int i = 0; i < segments.conversion_segment(0).candidates_size(); ++i) {
      if (segments.conversion_segment(0).candidate(i).key == "あい") {
        first_ai_index = i;
        break;
      }
    }
    ASSERT_NE(first_ai_index, -1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(first_ai_index).value,
              "哀");
  }
}

TEST_F(ConverterTest, SuppressionEntryShouldBePrioritized) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  // "哀" is not in the test dictionary
  user_defined_entries.push_back(
      UserDefinedEntry("あい", "哀", UserDictionary::NOUN));
  user_defined_entries.push_back(
      UserDefinedEntry("あい", "哀", UserDictionary::SUPPRESSION_WORD));

  std::unique_ptr<Converter> converter = CreateConverterWithUserDefinedEntries(
      user_defined_entries, STUB_PREDICTOR);

  {
    Segments segments;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("あい", ConversionRequest::CONVERSION), &segments));
    ASSERT_EQ(segments.conversion_segments_size(), 1);
    ASSERT_LT(1, segments.conversion_segment(0).candidates_size());
    EXPECT_FALSE(FindCandidateByValue("哀", segments.conversion_segment(0)));
  }
}

TEST_F(ConverterTest, SuppressionEntryShouldBePrioritizedPrediction) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  // "哀" is not in the test dictionary
  user_defined_entries.push_back(
      UserDefinedEntry("あい", "哀", UserDictionary::NOUN));
  user_defined_entries.push_back(
      UserDefinedEntry("あい", "哀", UserDictionary::SUPPRESSION_WORD));

  PredictorType types[] = {DEFAULT_PREDICTOR, MOBILE_PREDICTOR};
  for (int i = 0; i < std::size(types); ++i) {
    std::unique_ptr<Converter> converter =
        CreateConverterWithUserDefinedEntries(user_defined_entries, types[i]);
    {
      Segments segments;
      EXPECT_TRUE(converter->StartPrediction(
          ConvReq("あい", ConversionRequest::PREDICTION), &segments));
      ASSERT_EQ(segments.conversion_segments_size(), 1);
      ASSERT_LT(1, segments.conversion_segment(0).candidates_size());
      EXPECT_FALSE(FindCandidateByValue("哀", segments.conversion_segment(0)));
    }
  }
}

TEST_F(ConverterTest, AbbreviationShouldBeIndependent) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  user_defined_entries.push_back(
      UserDefinedEntry("じゅ", "Google+", UserDictionary::ABBREVIATION));

  std::unique_ptr<Converter> converter = CreateConverterWithUserDefinedEntries(
      user_defined_entries, STUB_PREDICTOR);

  {
    Segments segments;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("じゅうじか", ConversionRequest::CONVERSION), &segments));
    ASSERT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_FALSE(
        FindCandidateByValue("Google+うじか", segments.conversion_segment(0)));
  }
}

TEST_F(ConverterTest, AbbreviationShouldBeIndependentPrediction) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  user_defined_entries.push_back(
      UserDefinedEntry("じゅ", "Google+", UserDictionary::ABBREVIATION));

  PredictorType types[] = {DEFAULT_PREDICTOR, MOBILE_PREDICTOR};
  for (int i = 0; i < std::size(types); ++i) {
    std::unique_ptr<Converter> converter =
        CreateConverterWithUserDefinedEntries(user_defined_entries, types[i]);

    {
      Segments segments;
      EXPECT_TRUE(converter->StartPrediction(
          ConvReq("じゅうじか", ConversionRequest::PREDICTION), &segments));
      ASSERT_EQ(segments.conversion_segments_size(), 1);
      EXPECT_FALSE(FindCandidateByValue("Google+うじか",
                                        segments.conversion_segment(0)));
    }
  }
}

TEST_F(ConverterTest, SuggestionOnlyShouldBeIndependent) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  user_defined_entries.push_back(
      UserDefinedEntry("じゅ", "Google+", UserDictionary::SUGGESTION_ONLY));

  std::unique_ptr<Converter> converter = CreateConverterWithUserDefinedEntries(
      user_defined_entries, STUB_PREDICTOR);

  {
    Segments segments;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("じゅうじか", ConversionRequest::CONVERSION), &segments));
    ASSERT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_FALSE(
        FindCandidateByValue("Google+うじか", segments.conversion_segment(0)));
  }
}

TEST_F(ConverterTest, SuggestionOnlyShouldBeIndependentPrediction) {
  using user_dictionary::UserDictionary;
  std::vector<UserDefinedEntry> user_defined_entries;
  user_defined_entries.push_back(
      UserDefinedEntry("じゅ", "Google+", UserDictionary::SUGGESTION_ONLY));

  PredictorType types[] = {DEFAULT_PREDICTOR, MOBILE_PREDICTOR};
  for (int i = 0; i < std::size(types); ++i) {
    std::unique_ptr<Converter> converter =
        CreateConverterWithUserDefinedEntries(user_defined_entries, types[i]);

    {
      Segments segments;
      EXPECT_TRUE(converter->StartConversion(
          ConvReq("じゅうじか", ConversionRequest::CONVERSION), &segments));
      ASSERT_EQ(segments.conversion_segments_size(), 1);
      EXPECT_FALSE(FindCandidateByValue("Google+うじか",
                                        segments.conversion_segment(0)));
    }
  }
}

TEST_F(ConverterTest, RewriterShouldRespectDefaultCandidates) {
  std::unique_ptr<Engine> engine = CreateEngine();
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);

  config::Config config;
  config::ConfigHandler::GetDefaultConfig(&config);
  commands::Request request;
  request_test_util::FillMobileRequest(&request);
  auto table = std::make_shared<composer::Table>();
  composer::Composer composer(table, request, config);
  composer.SetPreeditTextForTestOnly("あい");
  Segments segments;

  ConversionRequest::Options options = {
      .request_type = ConversionRequest::PREDICTION,
  };
  const ConversionRequest conversion_request =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequestView(request)
          .SetConfigView(config)
          .SetHistoryResult(HistorySegmentsToResult(segments))
          .SetOptions(std::move(options))
          .Build();

  // Remember user history 3 times after getting the top candidate
  std::string top_candidate;
  absl::flat_hash_set<std::string> seen;
  for (int i = 0; i < 4; ++i) {
    segments.Clear();
    EXPECT_TRUE(converter->StartPrediction(conversion_request, &segments));
    const Segment& segment = segments.conversion_segment(0);
    if (i == 0) {
      top_candidate = segment.candidate(0).value;
      seen.insert(top_candidate);
      continue;
    }

    for (int index = 0; index < segment.candidates_size(); ++index) {
      const bool inserted = seen.insert(segment.candidate(index).value).second;
      if (inserted) {
        ASSERT_TRUE(converter->CommitSegmentValue(&segments, 0, index));
        break;
      }
    }
    converter->FinishConversion(conversion_request, &segments);
  }

  segments.Clear();
  EXPECT_TRUE(converter->StartPrediction(conversion_request, &segments));

  int default_candidate_index = -1;
  for (int i = 0; i < segments.conversion_segment(0).candidates_size(); ++i) {
    if (segments.conversion_segment(0).candidate(i).value == top_candidate) {
      default_candidate_index = i;
      break;
    }
  }
  ASSERT_NE(default_candidate_index, -1);
  EXPECT_LE(default_candidate_index, 3);
}

TEST_F(ConverterTest,
       DoNotPromotePrefixOfSingleEntryForEnrichPartialCandidates) {
  std::unique_ptr<Engine> engine = CreateEngine();
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);

  commands::Request request;
  config::Config config;
  config::ConfigHandler::GetDefaultConfig(&config);
  auto table = std::make_shared<composer::Table>();
  composer::Composer composer(table, request, config);
  request_test_util::FillMobileRequest(&request);
  composer.SetPreeditTextForTestOnly("おつかれ");

  ConversionRequest::Options options = {.request_type =
                                            ConversionRequest::PREDICTION};
  const ConversionRequest conversion_request =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequestView(request)
          .SetConfigView(config)
          .SetOptions(std::move(options))
          .Build();

  Segments segments;

  EXPECT_TRUE(converter->StartPrediction(conversion_request, &segments));

  int o_index = GetCandidateIndexByValue("お", segments.conversion_segment(0));
  int otsukare_index =
      GetCandidateIndexByValue("お疲れ", segments.conversion_segment(0));
  EXPECT_NE(otsukare_index, -1);
  EXPECT_TRUE(o_index == -1 || (otsukare_index < o_index));
}

TEST_F(ConverterTest, DoNotAddOverlappingNodesForPrediction) {
  std::unique_ptr<Engine> engine = CreateEngine();
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();
  CHECK(converter);
  commands::Request request;
  config::Config config;
  config::ConfigHandler::GetDefaultConfig(&config);
  auto table = std::make_shared<composer::Table>();
  composer::Composer composer(table, request, config);
  request_test_util::FillMobileRequest(&request);
  const dictionary::PosMatcher pos_matcher(
      engine->GetModulesForTesting().GetDataManager().GetPosMatcherData());
  ConversionRequest::Options options = {
      .request_type = ConversionRequest::PREDICTION,
      .create_partial_candidates = true,
  };

  Segments segments;
  // History segment.
  {
    Segment* segment = segments.add_segment();
    segment->set_key("に");
    segment->set_segment_type(Segment::HISTORY);
    Candidate* candidate = segment->add_candidate();
    candidate->key = "に";
    candidate->value = "に";
    // Hack: Get POS for "助詞".
    // The POS group of the test dictionary entries, "に" and "にて" should be
    // the same to trigger overlapping lookup.
    candidate->lid = pos_matcher.GetAcceptableParticleAtBeginOfSegmentId();
  }
  composer.SetPreeditTextForTestOnly("てはい");

  const ConversionRequest conversion_request =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequestView(request)
          .SetConfigView(config)
          .SetHistoryResult(HistorySegmentsToResult(segments))
          .SetOptions(std::move(options))
          .Build();

  EXPECT_TRUE(converter->StartPrediction(conversion_request, &segments));
  EXPECT_FALSE(FindCandidateByValue("て廃", segments.conversion_segment(0)));
}

TEST_F(ConverterTest, RevertConversion) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  EXPECT_CALL(*mock_predictor, Revert(_)).Times(1);
  EXPECT_CALL(*mock_rewriter, Revert(_)).Times(1);

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  Segments segments;
  segments.set_revert_id(10);

  converter->RevertConversion(&segments);
}

TEST_F(ConverterTest, ResizeSegmentWithOffset) {
  constexpr Segment::SegmentType kFixedBoundary = Segment::FIXED_BOUNDARY;
  constexpr Segment::SegmentType kFree = Segment::FREE;

  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  {
    // Resize {"あいうえ"} to {"あいう", "え"}
    Segments segments;
    AddSegment("あいうえ", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const int offset = -1;
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(converter->ResizeSegment(&segments, convreq,
                                         start_segment_index, offset));
    ASSERT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFree);
  }

  {
    // Resize {"あ", "い", "う", "え"} to {"あいう", "え"}
    Segments segments;
    AddSegment("あ", kFree, segments);
    AddSegment("い", kFree, segments);
    AddSegment("う", kFree, segments);
    AddSegment("え", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const int offset = 2;
    EXPECT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_TRUE(converter->ResizeSegment(&segments, convreq,
                                         start_segment_index, offset));
    ASSERT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFree);
  }

  {
    // Resize {"あ", "い", "う", "え"} to {"あ", "いう", "え"}
    Segments segments;
    AddSegment("あ", kFree, segments);
    AddSegment("い", kFree, segments);
    AddSegment("う", kFree, segments);
    AddSegment("え", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 1;
    const int offset = 1;
    EXPECT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_TRUE(converter->ResizeSegment(&segments, convreq,
                                         start_segment_index, offset));
    ASSERT_EQ(segments.conversion_segments_size(), 3);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あ");
    EXPECT_EQ(segments.conversion_segment(1).key(), "いう");
    EXPECT_EQ(segments.conversion_segment(2).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFree);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(2).segment_type(), kFree);
  }

  {
    // Invalid offset: 0
    Segments segments;
    AddSegment("あい", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const int offset = 0;
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_FALSE(converter->ResizeSegment(&segments, convreq,
                                          start_segment_index, offset));
  }

  {
    // Invalid offset: more than the end of the segment
    Segments segments;
    AddSegment("あい", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const int offset = 1;
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_FALSE(converter->ResizeSegment(&segments, convreq,
                                          start_segment_index, offset));
  }

  {
    // Invalid offset: less than the start of the segment
    Segments segments;
    AddSegment("あい", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const int offset = -2;
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_FALSE(converter->ResizeSegment(&segments, convreq,
                                          start_segment_index, offset));
  }
}

TEST_F(ConverterTest, ResizeSegmentsWithArray) {
  constexpr Segment::SegmentType kFixedBoundary = Segment::FIXED_BOUNDARY;
  constexpr Segment::SegmentType kFree = Segment::FREE;

  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  {
    // Resize {"あいうえ"} to {"あいう", "え"}
    Segments segments;
    AddSegment("あいうえ", kFree, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 2> size_array = {3, 1};
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
  }

  {
    // Resize {"あいうえ"} to {"あいう", "え"} with history segments.
    // Even if segments has histroy segments, arguments for ResizeSegment is not
    // changed.
    Segments segments;
    Segment& history0 = AddSegment("やゆよ", Segment::HISTORY, segments);
    PushBackCandidate("ヤユヨ", history0);
    Segment& history1 = AddSegment("わをん", Segment::HISTORY, segments);
    PushBackCandidate("ワヲン", history1);
    AddSegment("あいうえ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 2> size_array = {3, 1};
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
  }

  {
    // Resize {"あいうえ"} to {"あいう", "え"} where size_array contains 0
    // values.
    Segments segments;
    AddSegment("あいうえ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 8> size_array = {3, 1, 0, 0, 0, 0, 0, 0};
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
  }

  {
    // Resize {"あいうえおかきくけ"} to {"あい", "うえ", "お", "かき", "くけ"}
    Segments segments;
    AddSegment("あいうえおかきくけ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 5> size_array = {2, 2, 1, 2, 2};
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 5);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あい");
    EXPECT_EQ(segments.conversion_segment(1).key(), "うえ");
    EXPECT_EQ(segments.conversion_segment(2).key(), "お");
    EXPECT_EQ(segments.conversion_segment(3).key(), "かき");
    EXPECT_EQ(segments.conversion_segment(4).key(), "くけ");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(2).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(3).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(4).segment_type(), kFixedBoundary);
  }

  {
    // Resize {"あいう", "えお", "かき", "くけ"} to
    // {"あいうえ", "お", "かきくけ"}
    Segments segments;
    AddSegment("あいう", Segment::FREE, segments);
    AddSegment("えお", Segment::FREE, segments);
    AddSegment("かき", Segment::FREE, segments);
    AddSegment("くけ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 3> size_array = {4, 1, 4};
    EXPECT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 3);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいうえ");
    EXPECT_EQ(segments.conversion_segment(1).key(), "お");
    EXPECT_EQ(segments.conversion_segment(2).key(), "かきくけ");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(2).segment_type(), kFixedBoundary);
  }

  {
    // Resize {"あいう", "えお", "かき", "くけ"} to
    // {"あいうえ", "お"} and keeping {"かき", "くけ"} as-is.
    Segments segments;
    AddSegment("あいう", Segment::FREE, segments);
    AddSegment("えお", Segment::FREE, segments);
    AddSegment("かき", Segment::FREE, segments);
    AddSegment("くけ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 2> size_array = {4, 1};
    EXPECT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいうえ");
    EXPECT_EQ(segments.conversion_segment(1).key(), "お");
    EXPECT_EQ(segments.conversion_segment(2).key(), "かき");
    EXPECT_EQ(segments.conversion_segment(3).key(), "くけ");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFixedBoundary);
    EXPECT_EQ(segments.conversion_segment(2).segment_type(), kFree);
    EXPECT_EQ(segments.conversion_segment(3).segment_type(), kFree);
  }

  {
    // Resize {"あいうえ"} to {"あいう"} and keeping {"え"} as-is.
    Segments segments;
    AddSegment("あいうえ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 0;
    const std::array<uint8_t, 1> size_array = {3};
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));
    ASSERT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "え");
    EXPECT_EQ(segments.conversion_segment(0).segment_type(), kFixedBoundary);
    // Non specified segment (i.e. "え") is FREE to keep the consistency
    // with ResizeSegment.
    EXPECT_EQ(segments.conversion_segment(1).segment_type(), kFree);
  }

  {
    // Resize {"あいう", "えお", "かき", "くけ"} to {"かきくけ"} while
    // {"あいう", "えお"} are free to be modified.
    Segments segments;
    AddSegment("あいう", Segment::FREE, segments);
    AddSegment("えお", Segment::FREE, segments);
    AddSegment("かき", Segment::FREE, segments);
    AddSegment("くけ", Segment::FREE, segments);
    const ConversionRequest convreq;
    const int start_segment_index = 2;
    const std::array<uint8_t, 1> size_array = {4};
    EXPECT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_TRUE(converter->ResizeSegments(&segments, convreq,
                                          start_segment_index, size_array));

    // Since {"あいう", "えお"} may be modified too, the segment index for
    // "かきくけ" may be different from 2.
    const size_t resized_size = segments.conversion_segments_size();
    const Segment& last_segment = segments.conversion_segment(resized_size - 1);
    EXPECT_EQ(last_segment.key(), "かきくけ");
    EXPECT_EQ(last_segment.segment_type(), kFixedBoundary);
  }
}

TEST_F(ConverterTest, ResizeSegmentsRequest) {
  {
    const size_t index = 0;
    const std::array<uint8_t, 8> sizes = {1, 2, 3, 0, 0, 0, 0, 0};
    std::unique_ptr<Converter> converter = CreateConverter(
        std::make_unique<ResizeSegmentsRewriter>(index, sizes), STUB_PREDICTOR);

    Segments segments;

    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("あいうえおかき").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));

    ASSERT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あ");
    EXPECT_EQ(segments.conversion_segment(1).key(), "いう");
    EXPECT_EQ(segments.conversion_segment(2).key(), "えおか");
    EXPECT_EQ(segments.conversion_segment(3).key(), "き");
  }

  {
    const size_t index = 0;
    const std::array<uint8_t, 8> sizes = {3, 3, 0, 0, 0, 0, 0};
    std::unique_ptr<Converter> converter = CreateConverter(
        std::make_unique<ResizeSegmentsRewriter>(index, sizes), STUB_PREDICTOR);

    Segments segments;

    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("あいうえおかき").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));

    ASSERT_EQ(segments.conversion_segments_size(), 3);
    EXPECT_EQ(segments.conversion_segment(0).key(), "あいう");
    EXPECT_EQ(segments.conversion_segment(1).key(), "えおか");
    EXPECT_EQ(segments.conversion_segment(2).key(), "き");
  }

  {
    const size_t index = 1;
    const std::array<uint8_t, 8> sizes = {1, 2, 0, 0, 0, 0, 0};
    std::unique_ptr<Converter> converter = CreateConverter(
        std::make_unique<ResizeSegmentsRewriter>(index, sizes), STUB_PREDICTOR);

    Segments segments;

    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("あいうえおかき").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));

    // The total size of segments and the size of the first segment are not
    // specified.
    ASSERT_GE(segments.conversion_segments_size(), 3);
    ASSERT_LE(Util::CharsLen(segments.conversion_segment(0).key()), 4);

    EXPECT_EQ(Util::CharsLen(segments.conversion_segment(1).key()), 1);
    EXPECT_EQ(Util::CharsLen(segments.conversion_segment(2).key()), 2);
  }
}

TEST_F(ConverterTest, IntegrationWithCalculatorRewriter) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  {
    // Default (enable_multi_segment_candidate = false).
    Segments segments;
    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("1+1=").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "2");
  }

  {
    // enable_multi_segment_candidate = true.
    Segments segments;
    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest convreq = ConversionRequestBuilder()
                                          .SetRequest(request_proto)
                                          .SetKey("1+1=")
                                          .Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 4);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "2");
    EXPECT_EQ(
        segments.conversion_segment(0).candidate(0).converted_segment_count, 4);
  }
}

TEST_F(ConverterTest, IntegrationWithDateRewriter) {
  MockDictionary dictionary;
  // Since DateRewriter is not used in some build targets, the test needs to
  // explicitly add it to the converter.
  std::unique_ptr<Converter> converter = CreateConverter(
      std::make_unique<DateRewriter>(dictionary), STUB_PREDICTOR);

  {
    // Default (enable_multi_segment_candidate = false):
    // Multi-segment is merged into 1 segment via CheckResizeSegmentsRequest.
    Segments segments;
    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("へいせい30ねん").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("2018年", segments.conversion_segment(0)));
  }

  {
    // enable_multi_segment_candidate = true:
    // Multi-segment candidates are generated directly across segments.
    Segments segments;
    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest convreq = ConversionRequestBuilder()
                                          .SetRequest(request_proto)
                                          .SetKey("へいせい30ねん")
                                          .Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_GE(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("2018年", segments.conversion_segment(0)));
  }

  {
    Segments segments;
    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("794ねん").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(
        FindCandidateByValue("延暦13年", segments.conversion_segment(0)));
  }
}

TEST_F(ConverterTest, IntegrationWithSymbolRewriter) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  {
    // Default (enable_multi_segment_candidate = false).
    Segments segments;
    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("ー>").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("→", segments.conversion_segment(0)));
  }

  {
    // enable_multi_segment_candidate = true.
    Segments segments;
    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest convreq = ConversionRequestBuilder()
                                          .SetRequest(request_proto)
                                          .SetKey("ー>")
                                          .Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 2);
    const int index =
        GetCandidateIndexByValue("→", segments.conversion_segment(0));
    EXPECT_NE(index, -1);
    EXPECT_EQ(
        segments.conversion_segment(0).candidate(index).converted_segment_count,
        2);
  }
}

TEST_F(ConverterTest, IntegrationWithUnicodeRewriter) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  {
    // Default (enable_multi_segment_candidate = false).
    Segments segments;
    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("U+3042").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("あ", segments.conversion_segment(0)));
  }

  {
    // enable_multi_segment_candidate = true.
    Segments segments;
    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest convreq = ConversionRequestBuilder()
                                          .SetRequest(request_proto)
                                          .SetKey("U+3042")
                                          .Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 3);
    const int index =
        GetCandidateIndexByValue("あ", segments.conversion_segment(0));
    EXPECT_NE(index, -1);
    EXPECT_EQ(
        segments.conversion_segment(0).candidate(index).converted_segment_count,
        3);
  }
}

TEST_F(ConverterTest, IntegrationWithSmallLetterRewriter) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  std::shared_ptr<const ConverterInterface> converter = engine->GetConverter();

  {
    // Default (enable_multi_segment_candidate = false).
    Segments segments;
    const ConversionRequest convreq =
        ConversionRequestBuilder().SetKey("^123").Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_TRUE(FindCandidateByValue("¹²³", segments.conversion_segment(0)));
  }

  {
    // enable_multi_segment_candidate = true.
    Segments segments;
    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest convreq = ConversionRequestBuilder()
                                          .SetRequest(request_proto)
                                          .SetKey("^123")
                                          .Build();
    ASSERT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 2);
    const int index =
        GetCandidateIndexByValue("¹²³", segments.conversion_segment(0));
    EXPECT_NE(index, -1);
    EXPECT_EQ(
        segments.conversion_segment(0).candidate(index).converted_segment_count,
        2);
  }
}

TEST_F(ConverterTest, PopulateReadingOfCommittedCandidateIfMissing) {
  ASSERT_OK_AND_ASSIGN(std::unique_ptr<Engine> engine,
                       MockDataEngineFactory::Create());
  const std::shared_ptr<const ConverterInterface> converter =
      engine->GetConverter();

  // Test the case where value == content_value.
  {
    Segments segments;
    Segment* segment = segments.add_segment();

    Candidate* cand1 = segment->add_candidate();
    cand1->value = "東京";
    cand1->content_value = "東京";

    Candidate* cand2 = segment->add_candidate();
    cand2->value = "大阪";
    cand2->content_value = "大阪";

    Candidate* cand3 = segment->add_candidate();
    cand3->value = "群馬";
    cand3->content_value = "群馬";

    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();
    converter->FinishConversion(convreq, &segments);
    EXPECT_EQ(cand1->key, "とうきょう");
    EXPECT_EQ(cand1->content_key, "とうきょう");
    EXPECT_TRUE(cand2->key.empty());
    EXPECT_TRUE(cand2->content_key.empty());
    EXPECT_TRUE(cand3->key.empty());
    EXPECT_TRUE(cand3->content_key.empty());
  }
  // Test the case where value != content_value.
  {
    Segments segments;
    Segment* segment = segments.add_segment();

    Candidate* cand1 = segment->add_candidate();
    cand1->value = "東京に";
    cand1->content_value = "東京";

    Candidate* cand2 = segment->add_candidate();
    cand2->value = "大阪に";
    cand2->content_value = "大阪";

    Candidate* cand3 = segment->add_candidate();
    cand3->value = "群馬に";
    cand3->content_value = "群馬";

    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();
    converter->FinishConversion(convreq, &segments);
    EXPECT_EQ(cand1->key, "とうきょうに");
    EXPECT_EQ(cand1->content_key, "とうきょう");
    EXPECT_TRUE(cand2->key.empty());
    EXPECT_TRUE(cand2->content_key.empty());
    EXPECT_TRUE(cand3->key.empty());
    EXPECT_TRUE(cand3->content_key.empty());
  }
  // Test the case where value != content_value and the functional value is not
  // Hiragana. We cannot add the reading in this case.
  {
    Segments segments;
    Segment* segment = segments.add_segment();

    Candidate* cand1 = segment->add_candidate();
    cand1->value = "東京便";
    cand1->content_value = "東京";

    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();
    converter->FinishConversion(convreq, &segments);
    EXPECT_TRUE(cand1->key.empty());
    EXPECT_TRUE(cand1->content_key.empty());
  }
  // Test the case where value != content_value and content_value is empty.
  {
    Segments segments;
    Segment* segment = segments.add_segment();

    Candidate* cand1 = segment->add_candidate();
    cand1->value = "東京";
    cand1->content_value.clear();

    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();
    converter->FinishConversion(convreq, &segments);
    EXPECT_TRUE(cand1->key.empty());
    EXPECT_TRUE(cand1->content_key.empty());
  }
}

TEST_F(ConverterTest, Bugfix424676259) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> results;

  prediction::Result result;
  result.key = "3:30から";
  result.value = "３：３０から";

  // 3|:|30から
  result.inner_segment_boundary =
      BuildInnerSegmentBoundary({{1, 3, 1, 3},    // 3
                                 {1, 3, 1, 3},    // :
                                 {8, 12, 2, 6}},  // ３０_から
                                result.key, result.value);

  results.emplace_back(std::move(result));

  EXPECT_CALL(*mock_predictor, Predict(_)).WillRepeatedly(Return(results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request;
  request.set_mixed_conversion(true);
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetRequestView(request)
          .SetRequestType(ConversionRequest::SUGGESTION)
          .Build();

  converter::Segments segments;
  EXPECT_TRUE(converter->StartPrediction(convreq, &segments));

  ASSERT_EQ(segments.segments_size(), 1);
  const converter::Segment& segment = segments.segment(0);
  ASSERT_EQ(segment.candidates_size(), 1);
  const converter::Candidate& candidate = segment.candidate(0);

  EXPECT_EQ(candidate.key, "3:30から");
  EXPECT_EQ(candidate.value, "３：３０から");
  EXPECT_EQ(candidate.content_key, "3:30");
  EXPECT_EQ(candidate.content_value, "３：３０");
  EXPECT_EQ(candidate.inner_segment_boundary,
            results[0].inner_segment_boundary);
}

TEST_F(ConverterTest, CommitContext) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  EXPECT_CALL(*mock_predictor, CommitContext(_)).WillOnce(Return());

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  const ConversionRequest convreq = ConversionRequestBuilder().Build();
  converter->CommitContext(convreq);
}

TEST_F(ConverterTest, AddUserHistory) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  EXPECT_CALL(*mock_predictor, AddHistoryEntry("key", "value"))
      .WillOnce(Return(true));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  EXPECT_TRUE(converter->AddUserHistory("key", "value"));
}

TEST_F(ConverterTest, PostCorrectInConversionMode) {
  // Test 1: PostCorrect modifies value without changing inner segment boundary.
  // "わたしのなまえ" -> "私の名前" (1 segment) is corrected to "僕の名前".
  {
    class ValueModifyingSupplementalModel
        : public engine::MockSupplementalModel {
     public:
      bool IsAvailable() const override { return true; }
      void PostCorrect(
          const ConversionRequest& request,
          std::vector<prediction::Result>& results) const override {
        if (!results.empty()) {
          results.front().value = "僕の名前";
          InnerSegmentBoundaryBuilder builder;
          builder.Add(results.front().key.size(), results.front().value.size(),
                      results.front().key.size(), results.front().value.size());
          results.front().inner_segment_boundary =
              builder.Build(results.front().key, results.front().value);
        }
      }
    };

    auto supplemental_model = std::make_unique<
        ::testing::NiceMock<ValueModifyingSupplementalModel>>();

    ASSERT_OK_AND_ASSIGN(
        std::unique_ptr<engine::Modules> modules,
        engine::ModulesPresetBuilder()
            .PresetSupplementalModel(std::move(supplemental_model))
            .Build(std::make_unique<testing::MockDataManager>()));
    auto rewriter = std::make_unique<Rewriter>(*modules);
    std::unique_ptr<Converter> converter = CreateConverter(
        std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_disable_legacy_rewriter_in_all_conversion_mode(
            RewriterInterface::kDisableCollocation);
    composer::Composer composer;
    composer.SetPreeditTextForTestOnly("わたしのなまえ");
    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequest(request_proto)
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();

    Segments segments;
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "僕の名前");

    // When kDisableCollocation is not set, PostCorrect is not applied in
    // conversion mode.
    Segments segments_legacy;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("わたしのなまえ", ConversionRequest::CONVERSION),
        &segments_legacy));
    EXPECT_EQ(segments_legacy.conversion_segments_size(), 2);
    EXPECT_EQ(segments_legacy.conversion_segment(0).candidate(0).value, "私の");
    EXPECT_EQ(segments_legacy.conversion_segment(1).candidate(0).value, "名前");
  }

  // Test 2: PostCorrect changes inner segment boundary requiring Resize.
  // "しんだいしゃ" -> "寝台車" (1 segment) is corrected to
  // "死んだ" (3 chars, 9 bytes) + "医者" (2 chars, 6 bytes).
  {
    class ResizingSupplementalModel : public engine::MockSupplementalModel {
     public:
      bool IsAvailable() const override { return true; }
      void PostCorrect(
          const ConversionRequest& request,
          std::vector<prediction::Result>& results) const override {
        if (!results.empty()) {
          results.front().key = "しんだいしゃ";
          results.front().value = "死んだ医者";
          InnerSegmentBoundaryBuilder builder;
          builder.Add(9, 9, 9, 9);  // しんだ (9 bytes) -> 死んだ (9 bytes)
          builder.Add(9, 6, 9, 6);  // いしゃ (9 bytes) -> 医者 (6 bytes)
          results.front().inner_segment_boundary =
              builder.Build(results.front().key, results.front().value);
        }
      }
    };

    auto supplemental_model =
        std::make_unique<::testing::NiceMock<ResizingSupplementalModel>>();

    ASSERT_OK_AND_ASSIGN(
        std::unique_ptr<engine::Modules> modules,
        engine::ModulesPresetBuilder()
            .PresetSupplementalModel(std::move(supplemental_model))
            .Build(std::make_unique<testing::MockDataManager>()));

    auto rewriter = std::make_unique<Rewriter>(*modules);
    std::unique_ptr<Converter> converter = CreateConverter(
        std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_disable_legacy_rewriter_in_all_conversion_mode(
            RewriterInterface::kDisableCollocation);
    composer::Composer composer;
    composer.SetPreeditTextForTestOnly("しんだいしゃ");
    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequest(request_proto)
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();

    Segments segments;
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_EQ(segments.conversion_segments_size(), 2);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "死んだ");
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, "医者");

    // When kDisableCollocation is not set, PostCorrect is not applied in
    // conversion mode.
    Segments segments_legacy;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("しんだいしゃ", ConversionRequest::CONVERSION),
        &segments_legacy));
    EXPECT_EQ(segments_legacy.conversion_segments_size(), 2);
    EXPECT_EQ(segments_legacy.conversion_segment(0).candidate(0).value,
              "新だい");
  }

  // Test 3: Single-segment conversion passes N-best candidates to PostCorrect,
  // allowing supplemental model reranking.
  {
    class RerankingSupplementalModel : public engine::MockSupplementalModel {
     public:
      bool IsAvailable() const override { return true; }
      void PostCorrect(
          const ConversionRequest& request,
          std::vector<prediction::Result>& results) const override {
        EXPECT_GT(results.size(), 1);
        if (results.size() > 1) {
          std::rotate(results.begin(), results.begin() + 1,
                      results.begin() + 2);
        }
      }
    };

    auto supplemental_model =
        std::make_unique<::testing::NiceMock<RerankingSupplementalModel>>();

    ASSERT_OK_AND_ASSIGN(
        std::unique_ptr<engine::Modules> modules,
        engine::ModulesPresetBuilder()
            .PresetSupplementalModel(std::move(supplemental_model))
            .Build(std::make_unique<testing::MockDataManager>()));

    auto rewriter = std::make_unique<Rewriter>(*modules);
    std::unique_ptr<Converter> converter = CreateConverter(
        std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

    // First check default candidate order without PostCorrect.
    Segments segments_default;
    EXPECT_TRUE(converter->StartConversion(
        ConvReq("きょう", ConversionRequest::CONVERSION), &segments_default));
    ASSERT_EQ(segments_default.conversion_segments_size(), 1);
    ASSERT_GT(segments_default.conversion_segment(0).candidates_size(), 1);
    const std::string second_candidate_value =
        segments_default.conversion_segment(0).candidate(1).value;

    // Now run with kDisableCollocation so PostCorrect reranks candidate 1 to 0.
    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_disable_legacy_rewriter_in_all_conversion_mode(
            RewriterInterface::kDisableCollocation);
    composer::Composer composer;
    composer.SetPreeditTextForTestOnly("きょう");
    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequest(request_proto)
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();

    Segments segments;
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    ASSERT_EQ(segments.conversion_segments_size(), 1);
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value,
              second_candidate_value);
  }
}

TEST_F(ConverterTest, ApplyUserHistoryToConversionSingleSegmentTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> results(2);
  results[0].key = "きょう";
  results[0].value = "本日";
  results[0].lid = 100;
  results[0].rid = 200;
  results[0].cost = 500;
  results[0].wcost = 300;
  results[0].attributes = Attribute::USER_HISTORY_PREDICTION;

  results[1].key = "きょう";
  results[1].value = "今日";
  results[1].lid = 101;
  results[1].rid = 201;
  results[1].cost = 600;
  results[1].wcost = 400;
  results[1].attributes = Attribute::USER_HISTORY_PREDICTION;

  EXPECT_CALL(*mock_predictor, Convert(_)).WillRepeatedly(Return(results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  const Segment& seg = segments.conversion_segment(0);
  EXPECT_EQ(seg.candidate(0).value, "本日");
  EXPECT_TRUE(seg.candidate(0).attributes & Attribute::USER_HISTORY_PREDICTION);
}

TEST_F(ConverterTest, ApplyUserHistoryToConversionMultiSegmentTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> results(1);
  results[0].key = "わたしのなまえ";
  results[0].value = "僕の名字";
  InnerSegmentBoundaryBuilder builder;
  builder.Add(9, 3, 9, 3);  // わたし (9 bytes) -> 僕 (3 bytes)
  builder.Add(3, 3, 3, 3);  // の (3 bytes) -> の (3 bytes)
  builder.Add(9, 6, 9, 6);  // なまえ (9 bytes) -> 名字 (6 bytes)
  results[0].inner_segment_boundary =
      builder.Build(results[0].key, results[0].value);
  results[0].lid = 100;
  results[0].rid = 200;
  results[0].cost = 500;
  results[0].wcost = 300;

  EXPECT_CALL(*mock_predictor, Convert(_)).WillRepeatedly(Return(results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("わたしのなまえ");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 3);
  EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "僕");
  EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, "の");
  EXPECT_EQ(segments.conversion_segment(2).candidate(0).value, "名字");
}

TEST_F(ConverterTest, ApplyUserHistoryToConversionFallbackWithoutBoundaryTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> results(1);
  results[0].key = "わたしのなまえ";
  results[0].value = "僕の名字";
  results[0].attributes = Attribute::USER_HISTORY_EMPTY_INNER_SEGMENT_BOUNDARY;

  EXPECT_CALL(*mock_predictor, Convert(_)).WillRepeatedly(Return(results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("わたしのなまえ");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  EXPECT_GT(segments.conversion_segments_size(), 1);
  EXPECT_FALSE(segments.conversion_segment(0).candidate(0).attributes &
               Attribute::USER_HISTORY_PREDICTION);
}

TEST_F(ConverterTest,
       ApplyUserHistoryToConversionMultiSegmentWithoutBoundaryTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> results(1);
  results[0].key = "わたしのなまえ";
  results[0].value = "僕の名字";
  results[0].attributes = Attribute::USER_HISTORY_PREDICTION |
                          Attribute::USER_HISTORY_EMPTY_INNER_SEGMENT_BOUNDARY;

  EXPECT_CALL(*mock_predictor, Convert(_)).WillRepeatedly(Return(results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory);
  request_proto.mutable_decoder_experiment_params()
      ->set_enable_multi_segment_candidate(true);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("わたしのなまえ");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  EXPECT_GT(segments.conversion_segments_size(), 1);
  const Segment& seg0 = segments.conversion_segment(0);
  ASSERT_GT(seg0.candidates_size(), 0);
  EXPECT_EQ(seg0.candidate(0).value, "僕の名字");
  EXPECT_EQ(seg0.candidate(0).converted_segment_count,
            segments.conversion_segments_size());
  EXPECT_TRUE(seg0.candidate(0).attributes &
              Attribute::USER_HISTORY_PREDICTION);
}

TEST_F(ConverterTest, ApplyUserHistoryToConversionLegacyModeDisabledTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  EXPECT_CALL(*mock_predictor, Convert(_)).Times(0);

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
}

TEST_F(ConverterTest, ApplyUserHistoryToConversionE2ETest) {
  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));
  auto rewriter = std::make_unique<Rewriter>(*modules);
  std::unique_ptr<Converter> converter = CreateConverter(
      std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory);

  constexpr absl::string_view kKey = "わたしのなまえ";

  {
    composer::Composer composer;
    composer.SetPreeditTextForTestOnly(kKey);
    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequest(request_proto)
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();

    Segments segments;
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    EXPECT_GT(segments.conversion_segments_size(), 0);

    segments.mutable_conversion_segment(0)->set_segment_type(
        Segment::FIXED_VALUE);
    converter->FinishConversion(convreq, &segments);
  }

  {
    composer::Composer composer;
    composer.SetPreeditTextForTestOnly(kKey);
    const ConversionRequest convreq =
        ConversionRequestBuilder()
            .SetComposer(composer)
            .SetRequest(request_proto)
            .SetRequestType(ConversionRequest::CONVERSION)
            .Build();

    Segments segments;
    EXPECT_TRUE(converter->StartConversion(convreq, &segments));
    ASSERT_GT(segments.conversion_segments_size(), 0);
  }
}

TEST_F(ConverterTest,
       ApplyUserHistoryToConversionPartialCommitMultiSegmentTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> results(1);
  results[0].key = "わたしのなまえはなかのです";
  results[0].value = "僕の名字中野です";
  results[0].attributes = Attribute::USER_HISTORY_PREDICTION;
  InnerSegmentBoundaryBuilder builder;
  builder.Add(9, 3, 9, 3);      // わたし (9 bytes) -> 僕 (3 bytes)
  builder.Add(15, 9, 15, 9);    // のなまえは (15 bytes) -> の名字 (9 bytes)
  builder.Add(15, 12, 15, 12);  // なかのです (15 bytes) -> 中野です (12 bytes)
  results[0].inner_segment_boundary =
      builder.Build(results[0].key, results[0].value);
  results[0].lid = 100;
  results[0].rid = 200;
  results[0].cost = 500;
  results[0].wcost = 300;

  EXPECT_CALL(*mock_predictor, Convert(_)).WillRepeatedly(Return(results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(7);
  request_proto.mutable_decoder_experiment_params()
      ->set_enable_multi_segment_candidate(true);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("わたしのなまえはなかのです");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  ASSERT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 3);

  const int multi_cand_idx =
      GetCandidateIndexByValue("僕の名字", segments.conversion_segment(0));
  ASSERT_NE(multi_cand_idx, -1);
  EXPECT_EQ(segments.conversion_segment(0)
                .candidate(multi_cand_idx)
                .converted_segment_count,
            2);

  // Partially commit the multi-segment candidate on segment 0 (mobile tap).
  ASSERT_TRUE(converter->CommitSegments(&segments,
                                        {static_cast<size_t>(multi_cand_idx)}));
  EXPECT_EQ(segments.history_segments_size(), 1);
  EXPECT_EQ(segments.history_segment(0).key(), "わたしのなまえは");
  EXPECT_EQ(segments.history_segment(0).candidate(0).value, "僕の名字");
  EXPECT_EQ(segments.history_segment(0).candidate(0).converted_segment_count,
            1);

  // Covered segment 1 ("なまえは") was erased; only segment 2 ("なかのです")
  // remains.
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).key(), "なかのです");

  // FinishConversion commits the remaining conversion segment ("なかのです").
  segments.mutable_conversion_segment(0)->set_segment_type(
      Segment::FIXED_VALUE);
  converter->FinishConversion(convreq, &segments);
  EXPECT_EQ(segments.conversion_segments_size(), 0);
  ASSERT_EQ(segments.history_segments_size(), 2);
  EXPECT_EQ(segments.history_segment(0).candidate(0).value, "僕の名字");
  EXPECT_EQ(segments.history_segment(1).key(), "なかのです");
}

TEST_F(ConverterTest, ApplyPredictionToConversionMergedResultsTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  // UserHistory returns "本日" and "きょう".
  std::vector<prediction::Result> history_results(2);
  history_results[0].key = "きょう";
  history_results[0].value = "本日";
  history_results[0].lid = 100;
  history_results[0].rid = 200;
  history_results[0].cost = 500;
  history_results[0].wcost = 300;
  history_results[0].attributes = Attribute::USER_HISTORY_PREDICTION;
  history_results[1].key = "きょう";
  history_results[1].value = "きょう";
  history_results[1].attributes = Attribute::USER_HISTORY_PREDICTION;

  EXPECT_CALL(*mock_predictor, Convert(_))
      .WillRepeatedly(Return(history_results));

  // PostCorrect returns "本日" (duplicate of history[0]) and "今宵".
  class TestSupplementalModel : public engine::MockSupplementalModel {
   public:
    bool IsAvailable() const override { return true; }
    void PostCorrect(const ConversionRequest& request,
                     std::vector<prediction::Result>& results) const override {
      results.clear();
      prediction::Result r1;
      r1.key = "きょう";
      r1.value = "本日";  // Duplicate of history_results[0]
      results.push_back(r1);

      prediction::Result r2;
      r2.key = "きょう";
      r2.value = "今宵";
      results.push_back(r2);
    }
  };

  auto supplemental_model =
      std::make_unique<::testing::NiceMock<TestSupplementalModel>>();

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::ModulesPresetBuilder()
          .PresetSupplementalModel(std::move(supplemental_model))
          .Build(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory |
          RewriterInterface::kDisableCollocation);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  const Segment& seg = segments.conversion_segment(0);
  ASSERT_GE(seg.candidates_size(), 3);

  // Position 0: "本日" (User history prediction has higher priority)
  EXPECT_EQ(seg.candidate(0).value, "本日");
  EXPECT_TRUE(seg.candidate(0).attributes & Attribute::USER_HISTORY_PREDICTION);
  // Position 1: "きょう" (2nd user history candidate)
  EXPECT_EQ(seg.candidate(1).value, "きょう");
  // Position 2: "今宵" (PostCorrection result; duplicate "本日" was skipped)
  EXPECT_EQ(seg.candidate(2).value, "今宵");

  // Verify "本日" only appears once among top 3 candidates.
  int count_honjitsu = 0;
  for (size_t i = 0; i < std::min<size_t>(seg.candidates_size(), 3); ++i) {
    if (seg.candidate(i).value == "本日") {
      ++count_honjitsu;
    }
  }
  EXPECT_EQ(count_honjitsu, 1);
}

TEST_F(ConverterTest, ApplyPredictionToConversionWeakHistoryDemotedTest) {
  auto mock_predictor = std::make_unique<MockPredictor>();
  auto mock_rewriter = std::make_unique<MockRewriter>();

  std::vector<prediction::Result> history_results(1);
  history_results[0].key = "きょう";
  history_results[0].value = "本日";
  history_results[0].attributes = Attribute::WEAK_USER_HISTORY_PREDICTION;

  EXPECT_CALL(*mock_predictor, Convert(_))
      .WillRepeatedly(Return(history_results));

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::Modules::Create(std::make_unique<testing::MockDataManager>()));

  auto converter = std::make_unique<Converter>(
      std::move(modules),
      [](const engine::Modules& modules) {
        return std::make_unique<ImmutableConverter>(modules);
      },
      [&mock_predictor](
          const engine::Modules& modules, const ConverterInterface& converter,
          const ImmutableConverterInterface& immutable_converter) {
        return std::move(mock_predictor);
      },
      [&mock_rewriter](const engine::Modules& modules) {
        return std::move(mock_rewriter);
      });

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableUserSegmentHistory |
          RewriterInterface::kDisableUserBoundaryHistory);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  const Segment& seg = segments.conversion_segment(0);
  ASSERT_GE(seg.candidates_size(), 2);
  // Weak history candidate should not override default Viterbi result at pos 0.
  EXPECT_NE(seg.candidate(0).value, "本日");
  // Weak history candidate is demoted to subsequent candidate positions.
  EXPECT_EQ(seg.candidate(1).value, "本日");
  EXPECT_TRUE(seg.candidate(1).attributes &
              Attribute::WEAK_USER_HISTORY_PREDICTION);
}

TEST_F(ConverterTest,
       ApplyPredictionToConversionHandwritingModePostCorrectionSkippedTest) {
  class TestSupplementalModel : public engine::MockSupplementalModel {
   public:
    bool IsAvailable() const override { return true; }
    void PostCorrect(const ConversionRequest& request,
                     std::vector<prediction::Result>& results) const override {
      if (!results.empty()) {
        results.front().value = "今宵";
      }
    }
  };

  auto supplemental_model =
      std::make_unique<::testing::NiceMock<TestSupplementalModel>>();

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::ModulesPresetBuilder()
          .PresetSupplementalModel(std::move(supplemental_model))
          .Build(std::make_unique<testing::MockDataManager>()));

  auto rewriter = std::make_unique<Rewriter>(*modules);
  std::unique_ptr<Converter> converter = CreateConverter(
      std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

  commands::Request request_proto;
  request_proto.set_is_handwriting(true);
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableCollocation);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  const Segment& seg = segments.conversion_segment(0);
  // In handwriting mode, PostCorrection should be skipped.
  EXPECT_NE(seg.candidate(0).value, "今宵");
}

TEST_F(
    ConverterTest,
    ApplyPredictionToConversionUsedInPredictorRealtimeConversionSkippedTest) {
  class TestSupplementalModel : public engine::MockSupplementalModel {
   public:
    bool IsAvailable() const override { return true; }
    void PostCorrect(const ConversionRequest& request,
                     std::vector<prediction::Result>& results) const override {
      if (!results.empty()) {
        results.front().value = "今宵";
      }
    }
  };

  auto supplemental_model =
      std::make_unique<::testing::NiceMock<TestSupplementalModel>>();

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::ModulesPresetBuilder()
          .PresetSupplementalModel(std::move(supplemental_model))
          .Build(std::make_unique<testing::MockDataManager>()));

  auto rewriter = std::make_unique<Rewriter>(*modules);
  std::unique_ptr<Converter> converter = CreateConverter(
      std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableCollocation);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  ConversionRequest::Options options;
  options.request_type = ConversionRequest::CONVERSION;
  options.used_in_predictor_realtime_conversion = true;
  const ConversionRequest convreq = ConversionRequestBuilder()
                                        .SetComposer(composer)
                                        .SetRequest(request_proto)
                                        .SetOptions(options)
                                        .Build();

  Segments segments;
  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  const Segment& seg = segments.conversion_segment(0);
  // When used_in_predictor_realtime_conversion is true,
  // MaybeApplyPredictionToConversion should be skipped.
  EXPECT_NE(seg.candidate(0).value, "今宵");
}

TEST_F(ConverterTest, ApplyPredictionToConversionHistoryContextTest) {
  class HistoryContextCheckingSupplementalModel
      : public engine::MockSupplementalModel {
   public:
    bool IsAvailable() const override { return true; }
    void PostCorrect(const ConversionRequest& request,
                     std::vector<prediction::Result>& results) const override {
      EXPECT_EQ(request.converter_history_value(), "私は");
      if (!results.empty()) {
        results.front().value = "本日";
      }
    }
  };

  auto supplemental_model = std::make_unique<
      ::testing::NiceMock<HistoryContextCheckingSupplementalModel>>();

  ASSERT_OK_AND_ASSIGN(
      std::unique_ptr<engine::Modules> modules,
      engine::ModulesPresetBuilder()
          .PresetSupplementalModel(std::move(supplemental_model))
          .Build(std::make_unique<testing::MockDataManager>()));

  auto rewriter = std::make_unique<Rewriter>(*modules);
  std::unique_ptr<Converter> converter = CreateConverter(
      std::move(modules), std::move(rewriter), DEFAULT_PREDICTOR);

  commands::Request request_proto;
  request_proto.mutable_decoder_experiment_params()
      ->set_disable_legacy_rewriter_in_all_conversion_mode(
          RewriterInterface::kDisableCollocation);

  composer::Composer composer;
  composer.SetPreeditTextForTestOnly("きょう");
  const ConversionRequest convreq =
      ConversionRequestBuilder()
          .SetComposer(composer)
          .SetRequest(request_proto)
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  Segments segments;
  Segment* history_seg = segments.add_segment();
  history_seg->set_segment_type(Segment::HISTORY);
  history_seg->set_key("わたしは");
  Segment::Candidate* cand = history_seg->add_candidate();
  cand->key = "わたしは";
  cand->value = "私は";

  EXPECT_TRUE(converter->StartConversion(convreq, &segments));
  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "本日");
}

TEST_F(ConverterTest, FinishConversion_FullSentence) {
  std::unique_ptr<Converter> converter = CreateStubbedConverter();

  Segments segments;
  segments.set_max_history_segments_size(3);
  Segment* seg0 = segments.add_segment();
  seg0->set_key("わたしは");
  Candidate* cand0 = seg0->add_candidate();
  cand0->value = "私は";
  cand0->key = "わたしは";
  cand0->converted_segment_count = 2;

  Segment* seg1 = segments.add_segment();
  seg1->set_key("は");
  Candidate* cand1 = seg1->add_candidate();
  cand1->value = "は";
  cand1->key = "は";

  EXPECT_EQ(segments.conversion_segments_size(), 2);

  const ConversionRequest request =
      ConversionRequestBuilder()
          .SetRequestType(ConversionRequest::CONVERSION)
          .Build();

  converter->FinishConversion(request, &segments);

  EXPECT_EQ(segments.conversion_segments_size(), 0);
  EXPECT_EQ(segments.history_segments_size(), 1);
  EXPECT_EQ(segments.history_segment(0).key(), "わたしは");
  EXPECT_EQ(segments.history_segment(0).candidate(0).value, "私は");
}

TEST(CandidateTest, ConvertedSegmentCountZeroSafety) {
  Candidate cand;
  EXPECT_EQ(cand.converted_segment_count, 1);
  EXPECT_EQ(cand.effective_converted_segment_count(), 1);

  cand.converted_segment_count = 0;
  EXPECT_EQ(cand.effective_converted_segment_count(), 1);

  cand.converted_segment_count = 3;
  EXPECT_EQ(cand.effective_converted_segment_count(), 3);

  cand.Clear();
  EXPECT_EQ(cand.converted_segment_count, 1);
  EXPECT_EQ(cand.effective_converted_segment_count(), 1);
}

TEST_F(ConverterTest, PopulatePredictionResultsToSegmentsMultiSegment) {
  std::unique_ptr<Converter> converter = CreateStubbedConverter();
  ConverterTestPeer converter_peer(*converter);

  prediction::Result default_result;
  default_result.key = "ここではきものをぬぐ";
  default_result.value = "ここで履物を脱ぐ";
  default_result.inner_segment_boundary =
      BuildInnerSegmentBoundary({{9, 9, 9, 9}, {15, 9, 12, 6}, {6, 6, 6, 6}},
                                default_result.key, default_result.value);

  prediction::Result pred_result;
  pred_result.key = "ここではきものをぬぐ";
  pred_result.value = "ここでは着物を脱ぐ";
  pred_result.inner_segment_boundary =
      BuildInnerSegmentBoundary({{12, 12, 9, 9}, {12, 9, 9, 6}, {6, 6, 6, 6}},
                                pred_result.key, pred_result.value);

  const std::vector<prediction::Result> results = {pred_result};

  {
    // enable_multi_segment_candidate = false (legacy behavior):
    // Segments are resized to match prediction result boundaries.
    Segments segments;
    Segment* s0 = segments.add_segment();
    s0->set_key("ここで");
    Candidate* c0 = s0->add_candidate();
    c0->key = "ここで";
    c0->value = "ここで";
    c0->content_key = "ここで";
    c0->content_value = "ここで";

    Segment* s1 = segments.add_segment();
    s1->set_key("はきものを");
    Candidate* c1 = s1->add_candidate();
    c1->key = "はきものを";
    c1->value = "履物を";
    c1->content_key = "はきもの";
    c1->content_value = "履物";

    Segment* s2 = segments.add_segment();
    s2->set_key("ぬぐ");
    Candidate* c2 = s2->add_candidate();
    c2->key = "ぬぐ";
    c2->value = "脱ぐ";
    c2->content_key = "ぬぐ";
    c2->content_value = "脱ぐ";

    const ConversionRequest request = ConversionRequestBuilder().Build();
    converter_peer.PopulatePredictionResultsToSegments(request, default_result,
                                                       results, &segments);

    // Legacy behavior resizes segments according to prediction boundaries.
    EXPECT_EQ(segments.conversion_segments_size(), 3);
    EXPECT_EQ(segments.conversion_segment(0).key(), "ここでは");
    EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "ここでは");
    EXPECT_EQ(
        segments.conversion_segment(0).candidate(0).inner_segment_boundary,
        BuildInnerSegmentBoundary({{12, 12, 9, 9}}, "ここでは", "ここでは"));
    EXPECT_EQ(segments.conversion_segment(1).key(), "きものを");
    EXPECT_EQ(segments.conversion_segment(1).candidate(0).value, "着物を");
    EXPECT_EQ(
        segments.conversion_segment(1).candidate(0).inner_segment_boundary,
        BuildInnerSegmentBoundary({{12, 9, 9, 6}}, "きものを", "着物を"));
    EXPECT_EQ(segments.conversion_segment(2).key(), "ぬぐ");
    EXPECT_EQ(segments.conversion_segment(2).candidate(0).value, "脱ぐ");
    EXPECT_EQ(
        segments.conversion_segment(2).candidate(0).inner_segment_boundary,
        BuildInnerSegmentBoundary({{6, 6, 6, 6}}, "ぬぐ", "脱ぐ"));
  }

  {
    // enable_multi_segment_candidate = true:
    // Segments are NOT resized. "ここでは着物を" is added as a multi-segment
    // candidate with converted_segment_count = 2 in segment 0.
    // "脱ぐ" is applied to segment 2 with converted_segment_count = 1.
    Segments segments;
    Segment* s0 = segments.add_segment();
    s0->set_key("ここで");
    Candidate* c0 = s0->add_candidate();
    c0->key = "ここで";
    c0->value = "ここで";
    c0->content_key = "ここで";
    c0->content_value = "ここで";

    Segment* s1 = segments.add_segment();
    s1->set_key("はきものを");
    Candidate* c1 = s1->add_candidate();
    c1->key = "はきものを";
    c1->value = "履物を";
    c1->content_key = "はきもの";
    c1->content_value = "履物";

    Segment* s2 = segments.add_segment();
    s2->set_key("ぬぐ");
    Candidate* c2_other = s2->add_candidate();
    c2_other->key = "ぬぐ";
    c2_other->value = "塗ぐ";
    c2_other->content_key = "ぬぐ";
    c2_other->content_value = "塗ぐ";
    Candidate* c2 = s2->add_candidate();
    c2->key = "ぬぐ";
    c2->value = "脱ぐ";
    c2->content_key = "ぬぐ";
    c2->content_value = "脱ぐ";

    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest request =
        ConversionRequestBuilder().SetRequest(request_proto).Build();

    converter_peer.PopulatePredictionResultsToSegments(request, default_result,
                                                       results, &segments);

    // Segments structure is preserved (3 segments).
    ASSERT_EQ(segments.conversion_segments_size(), 3);
    EXPECT_EQ(segments.conversion_segment(0).key(), "ここで");
    EXPECT_EQ(segments.conversion_segment(1).key(), "はきものを");
    EXPECT_EQ(segments.conversion_segment(2).key(), "ぬぐ");

    // Segment 0 contains multi-segment candidate "ここでは着物を" with
    // converted_segment_count = 2.
    const Segment& seg0 = segments.conversion_segment(0);
    ASSERT_GT(seg0.candidates_size(), 0);
    EXPECT_EQ(seg0.candidate(0).value, "ここでは着物を");
    EXPECT_EQ(seg0.candidate(0).key, "ここではきものを");
    EXPECT_EQ(seg0.candidate(0).converted_segment_count, 2);

    // Segment 2 top candidate is moved to "脱ぐ".
    const Segment& seg2 = segments.conversion_segment(2);
    ASSERT_GT(seg2.candidates_size(), 0);
    EXPECT_EQ(seg2.candidate(0).value, "脱ぐ");
    EXPECT_EQ(seg2.candidate(0).converted_segment_count, 1);
  }

  {
    // Verify that multiple prediction results (up to 5) are inserted in order.
    prediction::Result pred_result2;
    pred_result2.key = "ここではきものをぬぐ";
    pred_result2.value = "此処では着物を脱ぐ";
    pred_result2.inner_segment_boundary =
        BuildInnerSegmentBoundary({{12, 12, 9, 9}, {12, 9, 9, 6}, {6, 6, 6, 6}},
                                  pred_result2.key, pred_result2.value);
    const std::vector<prediction::Result> multi_results = {pred_result,
                                                           pred_result2};

    Segments segments;
    Segment* s0 = segments.add_segment();
    s0->set_key("ここで");
    Candidate* c0 = s0->add_candidate();
    c0->key = "ここで";
    c0->value = "ここで";
    c0->content_key = "ここで";
    c0->content_value = "ここで";

    Segment* s1 = segments.add_segment();
    s1->set_key("はきものを");
    Candidate* c1 = s1->add_candidate();
    c1->key = "はきものを";
    c1->value = "履物を";
    c1->content_key = "はきもの";
    c1->content_value = "履物";

    Segment* s2 = segments.add_segment();
    s2->set_key("ぬぐ");
    Candidate* c2_other = s2->add_candidate();
    c2_other->key = "ぬぐ";
    c2_other->value = "塗ぐ";
    c2_other->content_key = "ぬぐ";
    c2_other->content_value = "塗ぐ";
    Candidate* c2 = s2->add_candidate();
    c2->key = "ぬぐ";
    c2->value = "脱ぐ";
    c2->content_key = "ぬぐ";
    c2->content_value = "脱ぐ";

    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest request =
        ConversionRequestBuilder().SetRequest(request_proto).Build();

    converter_peer.PopulatePredictionResultsToSegments(
        request, default_result, multi_results, &segments);

    const Segment& seg0 = segments.conversion_segment(0);
    ASSERT_GE(seg0.candidates_size(), 2);
    EXPECT_EQ(seg0.candidate(0).value, "ここでは着物を");
    EXPECT_EQ(seg0.candidate(0).converted_segment_count, 2);
    EXPECT_EQ(seg0.candidate(1).value, "此処では着物を");
    EXPECT_EQ(seg0.candidate(1).converted_segment_count, 2);

    // Verify that "脱ぐ" in segment 2 was promoted to pos 0 by result 0 and was
    // NOT demoted to pos 1 by result 1.
    const Segment& seg2 = segments.conversion_segment(2);
    ASSERT_GE(seg2.candidates_size(), 2);
    EXPECT_EQ(seg2.candidate(0).value, "脱ぐ");
    EXPECT_EQ(seg2.candidate(1).value, "塗ぐ");
  }
}

TEST_F(ConverterTest, PopulatePredictionResultsToSegmentsEmptyResults) {
  std::unique_ptr<Converter> converter = CreateStubbedConverter();
  ConverterTestPeer converter_peer(*converter);

  prediction::Result default_result;
  default_result.key = "きょう";
  default_result.value = "今日";

  Segments segments;
  Segment* s0 = segments.add_segment();
  s0->set_key("きょう");
  Candidate* c0 = s0->add_candidate();
  c0->key = "きょう";
  c0->value = "今日";

  const ConversionRequest request = ConversionRequestBuilder().Build();
  converter_peer.PopulatePredictionResultsToSegments(
      request, default_result, std::vector<prediction::Result>{}, &segments);

  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).candidates_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "今日");
}

TEST_F(ConverterTest, PopulatePredictionResultsToSegmentsResizeFailure) {
  std::unique_ptr<Converter> converter = CreateStubbedConverter();
  ConverterTestPeer converter_peer(*converter);

  prediction::Result default_result;
  default_result.key = "とうきょう";
  default_result.value = "東京";

  prediction::Result invalid_pred_result;
  invalid_pred_result.key = "";
  invalid_pred_result.value = "別表記";

  Segments segments;
  Segment* s0 = segments.add_segment();
  s0->set_key("とうきょう");
  Candidate* c0 = s0->add_candidate();
  c0->key = "とうきょう";
  c0->value = "東京";

  const ConversionRequest request = ConversionRequestBuilder().Build();
  converter_peer.PopulatePredictionResultsToSegments(
      request, default_result,
      std::vector<prediction::Result>{invalid_pred_result}, &segments);

  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).candidates_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).candidate(0).value, "東京");
}

TEST_F(ConverterTest,
       PopulatePredictionResultsToSegmentsLegacyMultiToSingleSegment) {
  std::unique_ptr<Converter> converter = CreateStubbedConverter();
  ConverterTestPeer converter_peer(*converter);

  prediction::Result default_result;
  default_result.key = "ここではきものをぬぐ";
  default_result.value = "ここで履物を脱ぐ";
  default_result.inner_segment_boundary =
      BuildInnerSegmentBoundary({{9, 9, 9, 9}, {15, 9, 12, 6}, {6, 6, 6, 6}},
                                default_result.key, default_result.value);

  // Prediction result that resizes multi-segment default (3 segments) into a
  // single segment.
  prediction::Result pred_result0;
  pred_result0.key = "ここではきものをぬぐ";
  pred_result0.value = "ここでは着物を脱ぐ";
  pred_result0.inner_segment_boundary = BuildInnerSegmentBoundary(
      {{30, 30, 27, 27}}, pred_result0.key, pred_result0.value);

  prediction::Result pred_result1;
  pred_result1.key = "ここではきものをぬぐ";
  pred_result1.value = "此処では着物を脱ぐ";
  pred_result1.inner_segment_boundary = BuildInnerSegmentBoundary(
      {{30, 30, 27, 27}}, pred_result1.key, pred_result1.value);

  const std::vector<prediction::Result> results = {pred_result0, pred_result1};

  Segments segments;
  Segment* s0 = segments.add_segment();
  s0->set_key("ここで");
  Candidate* c0 = s0->add_candidate();
  c0->key = "ここで";
  c0->value = "ここで";

  Segment* s1 = segments.add_segment();
  s1->set_key("はきものを");
  Candidate* c1 = s1->add_candidate();
  c1->key = "はきものを";
  c1->value = "履物を";

  Segment* s2 = segments.add_segment();
  s2->set_key("ぬぐ");
  Candidate* c2 = s2->add_candidate();
  c2->key = "ぬぐ";
  c2->value = "脱ぐ";

  // enable_multi_segment = false.
  // Because is_default_multi_segment was true, is_single_segment is false even
  // after resizing to 1 segment, so only pred_result0 is applied (not
  // pred_result1).
  const ConversionRequest request = ConversionRequestBuilder().Build();
  converter_peer.PopulatePredictionResultsToSegments(request, default_result,
                                                     results, &segments);

  ASSERT_EQ(segments.conversion_segments_size(), 1);
  EXPECT_EQ(segments.conversion_segment(0).key(), "ここではきものをぬぐ");
  EXPECT_EQ(segments.conversion_segment(0).candidate(0).value,
            "ここでは着物を脱ぐ");
  EXPECT_FALSE(FindCandidateByValue("此処では着物を脱ぐ",
                                    segments.conversion_segment(0)));
}

TEST_F(ConverterTest,
       PopulatePredictionResultsToSegmentsSingleSegmentWithEmptyResult) {
  std::unique_ptr<Converter> converter = CreateStubbedConverter();
  ConverterTestPeer converter_peer(*converter);

  prediction::Result default_result;
  default_result.key = "きょう";
  default_result.value = "今日";
  default_result.inner_segment_boundary = BuildInnerSegmentBoundary(
      {{9, 9, 6, 6}}, default_result.key, default_result.value);

  prediction::Result pred_result0;
  pred_result0.key = "きょう";
  pred_result0.value = "今日";
  pred_result0.inner_segment_boundary = BuildInnerSegmentBoundary(
      {{9, 9, 6, 6}}, pred_result0.key, pred_result0.value);

  prediction::Result empty_pred_result;
  empty_pred_result.key = "";
  empty_pred_result.value = "";

  prediction::Result pred_result2;
  pred_result2.key = "きょう";
  pred_result2.value = "教";
  pred_result2.inner_segment_boundary = BuildInnerSegmentBoundary(
      {{9, 9, 3, 3}}, pred_result2.key, pred_result2.value);

  const std::vector<prediction::Result> results = {
      pred_result0, empty_pred_result, pred_result2};

  {
    // enable_multi_segment = false
    Segments segments;
    Segment* s0 = segments.add_segment();
    s0->set_key("きょう");
    Candidate* c0 = s0->add_candidate();
    c0->key = "きょう";
    c0->value = "今日";

    const ConversionRequest request = ConversionRequestBuilder().Build();
    converter_peer.PopulatePredictionResultsToSegments(request, default_result,
                                                       results, &segments);

    ASSERT_EQ(segments.conversion_segments_size(), 1);
    const Segment& seg0 = segments.conversion_segment(0);
    EXPECT_TRUE(FindCandidateByValue("教", seg0));
  }

  {
    // enable_multi_segment = true
    Segments segments;
    Segment* s0 = segments.add_segment();
    s0->set_key("きょう");
    Candidate* c0 = s0->add_candidate();
    c0->key = "きょう";
    c0->value = "今日";

    commands::Request request_proto;
    request_proto.mutable_decoder_experiment_params()
        ->set_enable_multi_segment_candidate(true);
    const ConversionRequest request =
        ConversionRequestBuilder().SetRequest(request_proto).Build();

    converter_peer.PopulatePredictionResultsToSegments(request, default_result,
                                                       results, &segments);

    ASSERT_EQ(segments.conversion_segments_size(), 1);
    const Segment& seg0 = segments.conversion_segment(0);
    EXPECT_TRUE(FindCandidateByValue("教", seg0));
  }
}

}  // namespace converter
}  // namespace mozc
