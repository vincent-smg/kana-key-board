// Copyright 2010-2021, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "base/strings/unicode.h"

#include <bit>
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>

#include "absl/strings/string_view.h"
#include "base/bits.h"
#include "base/strings/internal/utf8_internal.h"

namespace mozc {
namespace strings {

size_t CharsLen(const absl::string_view sv) {
  // Every UTF-8 character has exactly one leading byte (0b0xxxxxxx, 0b110xxxxx,
  // 0b1110xxxx or 0b11110xxx) followed by zero or more continuation bytes
  // (0b10xxxxxx). Therefore, the character count is the byte count minus the
  // continuation byte count, and a byte is a continuation byte iff its bit 7
  // is set and bit 6 is clear.
  //
  // The main loop processes eight bytes at a time: `w & ~(w << 1)` keeps bit 7
  // of each byte only if bit 6 of the same byte is clear, so masking with
  // kHighBits leaves exactly one set bit per continuation byte, which
  // std::popcount then counts. The loop is written so that clang can
  // auto-vectorize it (SSE2 on x86-64, NEON on arm64).
  constexpr uint64_t kHighBits = 0x8080808080808080;
  constexpr size_t kBlockSize = sizeof(uint64_t);
  // Iterate over a local copy rather than the parameter itself. Under the
  // Windows x64 ABI, `sv` is passed by hidden reference, and mutating it in the
  // loop would make clang emit a runtime alias check against the string data
  // and a slower fallback loop that writes `sv` back to memory.
  absl::string_view rest = sv;
  size_t continuations = 0;
  while (rest.size() >= kBlockSize) {
    const uint64_t w = LoadUnaligned<uint64_t>(rest.data());
    continuations += std::popcount(w & ~(w << 1) & kHighBits);
    rest.remove_prefix(kBlockSize);
  }
  // The remaining bytes (fewer than eight) are checked one by one.
  for (const char c : rest) {
    continuations += (static_cast<uint8_t>(c) & 0xc0) == 0x80;
  }
  return sv.size() - continuations;
}

bool IsValidUtf8(const absl::string_view sv) {
  const char* const last = sv.data() + sv.size();
  for (const char* ptr = sv.data(); ptr != last;) {
    const utf8_internal::DecodeResult dr = utf8_internal::Decode(ptr, last);
    if (!dr.ok()) {
      return false;
    }
    ptr += dr.bytes_seen();
  }
  return true;
}

std::u32string Utf8ToUtf32(const absl::string_view sv) {
  const Utf8AsChars32 c32s{sv};
  // Most strings in Mozc are fairly short, so it's faster to depend on
  // automatic growth rather than calling reserve(CharsLen()).
  return std::u32string(c32s.begin(), c32s.end());
}

std::string Utf32ToUtf8(const std::u32string_view sv) {
  std::string result;
  // Same, most strings are fairly short, so it's faster to just append.
  for (const char32_t c : sv) {
    StrAppendChar32(&result, c);
  }
  return result;
}

absl::string_view Utf8Substring(absl::string_view sv, size_t pos) {
  const Utf8AsChars usv(sv);
  auto first = usv.begin();
  while (pos-- > 0) {
    ++first;
  }
  return usv.Substring(first);
}

absl::string_view Utf8Substring(absl::string_view sv, const size_t pos,
                                size_t count) {
  sv = Utf8Substring(sv, pos);
  const Utf8AsChars usv(sv);
  auto last = usv.begin();
  while (last != usv.end() && count-- > 0) {
    ++last;
  }
  return usv.Substring(usv.begin(), last);
}

absl::string_view Utf8SubstringFromEnd(absl::string_view sv, size_t count) {
  if (count == 0) {
    return sv.substr(sv.size());
  }
  const char* const begin = sv.data();
  const char* ptr = begin + sv.size();
  while (ptr > begin) {
    --ptr;
    if ((static_cast<uint8_t>(*ptr) & 0xc0) != 0x80) {
      if (--count == 0) {
        return absl::string_view(ptr, sv.data() + sv.size() - ptr);
      }
    }
  }
  return sv;
}

}  // namespace strings
}  // namespace mozc
